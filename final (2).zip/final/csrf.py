from flask import Flask, render_template, request, jsonify, url_for, redirect, url_for, Response, session
from neo4j import GraphDatabase
import pyodbc
import pypyodbc
import sqlalchemy
import jpype
import os
import model
import requests
from flask_wtf.csrf import CSRFProtect
from flask_wtf.csrf import CSRFError

print(1)

spring_host_sql_query = 'http://localhost:8080/fetchdata/mysql/query/'
spring_host_sql_data = 'http://localhost:8080/fetchdata/mysql/result/'
spring_host_neo4j_query = 'http://localhost:8080/fetchdata/neo4j/query/'
spring_host_neo4j_data = 'http://localhost:8080/fetchdata/neo4j/result/'

app = Flask(__name__)
app.secret_key = 'hqywueldtg'
csrf = CSRFProtect()
csrf.init_app(app)


@app.route('/')
def home():
    session['login'] = 0
    session['username'] = ''
    return render_template("index.html"), 200


@app.errorhandler(CSRFError)
def handle_csrf_error(e):
    return render_template('error.html', error=e.description), 400


@app.route("/elements.html")
def index1():
    if session['login'] == 0:
        return redirect(url_for('nologin'))

    return render_template("elements.html", user=session['username'])


@app.route('/notloggedin')
def nologin():
    return render_template('nologin.html')


@app.route("/login.html")
def login():
    return render_template("login.html")


@app.route("/logout")
def logout():
    session['login'] = 0
    session.pop('username', None)
    return render_template("login.html")


@app.route("/support.html")
def support():
    return render_template("support.html", user=session['username'])


@app.route("/confirm", methods=["POST"])
def confirm():
    print("here")
    username = ''
    password = ''
    status = ''
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        # Create variables for easy access
        username = request.form['username']
        password = request.form['password']
        conn = pyodbc.connect('Driver={SQL Server};'
                              'Server=LAPTOP-3PMTJ8NO\SQLEXPRESS01;'
                              'Database=accounts;'
                              'Trusted_Connection=yes;')

        cursor = conn.cursor()

        cursor.execute('''SELECT * FROM Table1 WHERE username = ? AND password = ?''', username, password)
        account = cursor.fetchone()
        # If account exists in accounts table in out database
        if account:
            # Create session data, we can access this data in other routes
            session['username'] = username
            session['login'] = 1
            status = 'OK'
        else:
            status = 'not'

    print(username)

    return jsonify({'username': username, 'password': password, 'status': status})


@app.route("/confirm2", methods=["POST"])
def confirm2():
    print("here")
    username = ''
    password = ''
    status = ''
    if request.method == 'POST' and 'fullname' in request.form and 'password' in request.form:
        # Create variables for easy access
        print("cmon")
        username = request.form['fullname']
        email = request.form['email']
        password = request.form['confirmpassword']
        print(username)
        print(email)
        print(password)
        conn = pyodbc.connect('Driver={SQL Server};'
                              'Server=LAPTOP-3PMTJ8NO\SQLEXPRESS01;'
                              'Database=accounts;'
                              'Trusted_Connection=yes;')

        cursor = conn.cursor()

        cursor.execute("INSERT INTO Table1(username, password, email) VALUES (?, ?, ?)", username, password, email)
        cursor.commit()

    print("here2")

    return jsonify({'username': username, 'password': password, 'status': status})


@app.route("/neo.html")
def neo():
    if session['login'] == 0:
        return redirect(url_for('nologin'))

    return render_template("neo.html", user=session['username'])


@app.route("/visualize", methods=["POST"])
def neo1():
    if session['login'] == 0:
        return redirect(url_for('nologin'))

    if request.method == "POST":
        query = request.form['cypher_query']
    else:
        query = "match (n) return n limit 5"
    return render_template("neo.html", query=query, user=session['username'])


@app.route("/", methods=["POST"])
def index():
    if session['login'] == 0:
        return redirect(url_for('nologin'))

    ##Build JSonPath Query
    result = ''
    o = ''
    graphs = []
    result2 = []
    sword = ""
    if request.method == "POST":
        r = []
        result = request.form.to_dict(flat=False)

        o = ""
        o = "$." + str(result['entity'][0])
        o = o + "[?("
        x = 1
        q = 'entities_' + str(x)
        w = 'attributes_' + str(x)
        r = 'operators_' + str(x)
        t = 'value_' + str(x)
        y = 'logical_' + str(x)

        s = []

        while q in result:
            if y in result:
                o = o + str(result[y][0])

            if str(result[q]) != str(result['entity']):

                if str(result[t][0]).isalpha():

                    o = o + "@." + str(result[q][0]) + "." + str(result[w][0]) + str(result[r][0]) + "'" + str(
                        result[t][0]) + "'"
                else:
                    o = o + "@." + str(result[q][0]) + "." + str(result[w][0]) + str(result[r][0]) + str(
                        result[t][0])
            else:
                if str(result[t][0]).isalpha():
                    o = o + "@." + str(result[w][0]) + str(result[r][0]) + "'" + str(result[t][0]) + "'"
                else:
                    o = o + "@." + str(result[w][0]) + str(result[r][0]) + str(
                        result[t][0])

            x = x + 1
            q = 'entities_' + str(x)
            w = 'attributes_' + str(x)
            r = 'operators_' + str(x)
            t = 'value_' + str(x)
            y = 'logical_' + str(x)

        o = o + ")]"

        x = 1
        q = 'e_' + str(x)
        w = 'a_' + str(x)
        temp_o = ""
        while q in result:
            temp_o = temp_o + "&fields=" + str(result[q][0]) + ":"
            if str(result[q]) != str(result['entity']):
                s.append(str(result[q][0]))
            for i in range(len(result[w])):
                temp_o = temp_o + str(result[w][i]) + ","
            temp_o = temp_o[:-1]
            x = x + 1
            q = 'e_' + str(x)
            w = 'a_' + str(x)

        if s:
            o = o + "&expands="
            for i in set(s):
                o = o + i + ","
            o = o[:-1]
        o = o + temp_o
        x = 1
        q = 'func_' + str(x)
        w = 'val_' + str(x)
        while q in result:
            o = o + "&" + str(result[q][0]) + "=" + str(result[w][0])
            x = x + 1
            q = 'func_' + str(x)
            w = 'val_' + str(x)

        ##Convert jsonPath  to underlying database query lang and fetch results
        print(f"jsonnpath query : {o}")

        if request.form['submit_button'] == 'Convert to Cypher':
            print("request sent ....cypher")
            return redirect(url_for('getresults', json=o, flag=1, newq="NO__CHANGE", nlquery='NO_NL', error='NO_ERROR'))



        elif request.form['submit_button'] == 'Convert to SQL':
            print("request sent ....SQL")
            return redirect(url_for('getresults', json=o, flag=2, newq="NO__CHANGE", nlquery='NO_NL', error='NO_ERROR'))

    return render_template("form2.html", result=str(result), W=o, WORDS=str(sword), list=graphs, result2=result2)


@app.route('/getresults/<json>/<flag>/<newq>/<nlquery>/<error>', methods=["GET"])
def getresults(json, flag, newq, nlquery, error):
    if session['login'] == 0:
        return redirect(url_for('nologin'))

    json = json.replace("?", "")
    graphs = []
    result2 = []
    result = 'HELLO'
    errflag = 0
    errormsg = ''
    n = ''

    if error != 'NO_ERROR':
        errflag = 1
        errormsg = error

    if nlquery == 'NO_NL':
        nlquery = ''

    if flag == "1":
        scroll = "res"
        n = 'CYPHER'
        print("request rcved", json, flag, " CYPHER")
        final = ""
        temp = requests.get(spring_host_neo4j_query + json)
        final = temp.text
        print("FINAL: ", final)
        r = requests.get(spring_host_neo4j_data + json)

        graphs = r.json()
        result2 = r.json()

        # result in json format
        listjson = r.json()  # {"customers":[{"birthdate":"21-09-2009","customer_name":"Daniel Bunch","customer_id":1.0,"customer_code":"FGF","age":13.0,"transactions":{"transaction_id":1.0,"transaction_date":"23-12-2016","quantity":13.0,"transaction_amount":33788.0},"gender":"Male"}]}

        if errflag == 0 and 'error' in listjson:
            errflag = 1
            errormsg = 'Check the Query Syntax...Given query is not Valid'

        if errflag == 1:
            return render_template('error.html', error=errormsg, user=session['username'])

        if newq != "NO__CHANGE":
            return render_template("result.html", scroll=scroll, result=str(result), W=json, WORDS=final, list=graphs,
                                   result2=result2,
                                   newq=newq, nlquery=nlquery, listjson=listjson, cypher='cypher',
                                   user=session['username'], n=n)

        return render_template("result.html", scroll=scroll, result=str(result), W=json, WORDS=final, list=graphs,
                               result2=result2,
                               nlquery=nlquery, listjson=listjson, cypher='cypher', user=session['username'], n=n)
    else:
        print("request rcved", json, flag, "SQL")
        final = ""
        e = ""
        n = 'SQL'
        conv_q = requests.get(spring_host_sql_query + json)
        final = conv_q.text
        print(f"sql query : {final}")
        print("FINAL: ", final)
        res = requests.get(spring_host_sql_data + json)
        result2 = res.json()
        listjson = res.json()
        print(listjson)
        if not listjson:
            e = "Sorry, no matching results found!"

        if errflag == 0 and 'error' in listjson:
            errflag = 1
            errormsg = 'Check the Query Syntax...Given query is not Valid'

        if errflag == 1:
            return render_template('error.html', error=errormsg, user=session['username'])
        if newq != "NO__CHANGE":
            return render_template("result.html", scroll='res', result=str(result), W=json, WORDS=final, list=graphs,
                                   result2=result2,
                                   newq=newq, nlquery=nlquery, listjson=listjson, user=session['username'], n=n, e=e)

        return render_template("result.html", scroll='res', result=str(result), W=json, WORDS=final, list=graphs,
                               result2=result2,
                               nlquery=nlquery, listjson=listjson, user=session['username'], n=n, e=e)


@app.route('/result.html')
def result():
    if session['login'] == 0:
        return redirect(url_for('nologin'))

    result = 'hahahah'
    o = 'hello'
    graphs = ['1']
    result2 = ['2']
    final = "final query"
    nlquery = 'get all customers'
    newq = "HAHAHA"
    return render_template("result.html", result=str(result), W=o, WORDS=final, list=graphs, result2=result2,
                           nlquery=nlquery, newq=newq, user=session['username'])


@app.route('/test')
def res():
    print(session['login'])
    session['hello'] = 'hellohello'

    return render_template('nologin.html', user=session['hello'])


@app.route('/index.html')
def form2():
    return render_template("index.html")


@app.route('/generic.html')
def starter():
    if session['login'] == 0:
        return redirect(url_for('nologin'))

    d = {
        'Customer': {'customer_id': 'INTEGER', 'customer_code': 'STRING', 'gender': 'STRING (Male/Female)',
                     'customer_name': 'STRING', 'age': 'INTEGER', 'contact_number': 'INTEGER'},
        'Product': {'product_id': 'INTEGER', 'product_name': 'STRING', 'product_type': 'STRING', 'price': 'FLOAT'},
        'Transaction': {'transaction_id': 'INTEGER', 'transaction_amount': 'FLOAT', 'transaction_date': 'DATE',
                        'quantity': 'INTEGER'}
    }

    auto_list = ["customer", "product", "transaction", "customer_id", "customer_code", "gender", "customer_name", "age",
                 "contact_number", "product_id", "price", "product_name", "product_type", "transaction_id",
                 "transaction_amount", "quantity", "transaction_date"]

    return render_template("generic.html", data=d, auto_list=auto_list, user=session['username'])


@app.route('/query', methods=['POST'])
def result1():
    if session['login'] == 0:
        return redirect(url_for('nologin'))
    query = request.form['q']
    type1 = request.form['typ']
    print("Query=" + query)
    print(type1)
    if query == '':
        print("query is None")
        return render_template('error.html', error="Empty", user=session['username'])
    flag = 1
    if type1 == 'SQL':
        flag = 2
    print(flag)
    q1, q, r = model.parse(query)
    newq, f = model.did_you_mean(query)

    if f == 0:
        newq = "NO__CHANGE"

    if query is None:
        return redirect(url_for('getresults', json=r, flag=flag, newq=newq, nlquery=query, error="Empty Q"))

    if 'error' in q:
        return redirect(url_for('getresults', json=r, flag=flag, newq=newq, nlquery=query, error=r))

    return redirect(url_for('getresults', json=r, flag=flag, newq=newq, nlquery=query, error='NO_ERROR'))


app.run(debug=True)

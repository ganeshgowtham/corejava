## ALL IMPORTS
import logging, io, json, warnings
import sys
import rasa
import spacy
from rasa.cli.utils import get_validated_path
from rasa.model import get_model, get_model_subdirectories
from rasa.nlu.model import Interpreter
import re
from datetime import date, datetime, timedelta

import gensim
from gensim.utils import SaveLoad 
import difflib
import numpy as np
from scipy import spatial
from operator import itemgetter

from spellchecker import SpellChecker


## WORD EMBEDDINGS MODEL
glove_vectors = gensim.utils.SaveLoad.load("D:\\sim_model")

##SPELL CHECKER
spell = SpellChecker()

## A CLASS FOR COMPARING SIMILARITY BETWEEN WORDS
class similarityChecker:
  glove_vectors = None
  index_to_key_set = None
  def __init__(self):
    self.glove_vectors = glove_vectors
    self.index_to_key_set = set(glove_vectors.index_to_key)

  def avg_feature_vector(self,sentence, model, num_features, index_to_key_set):
    words = sentence.split()
    feature_vec = np.zeros((num_features, ), dtype='float32')
    n_words = 0
    for word in words:
        if word in index_to_key_set:
            n_words += 1
            feature_vec = np.add(feature_vec, model[word])
    if (n_words > 0):
        feature_vec = np.divide(feature_vec, n_words)
    return feature_vec
  
  def remove_(self,s):
    s = s.replace('_',' ')
    return s

  def pattern_match_sim(self,a,b):
    seq = difflib.SequenceMatcher(None,a,b)
    d = seq.ratio()
    return d

  def compute_similarity(self,val1,val2):
    val1 = self.remove_(val1)
    val2 = self.remove_(val2)
  
    s1_afv = self.avg_feature_vector(val1, model=self.glove_vectors, num_features=300, index_to_key_set=self.index_to_key_set)
    s2_afv = self.avg_feature_vector(val2, model=self.glove_vectors, num_features=300, index_to_key_set=self.index_to_key_set)
    if(s2_afv.sum()==0 or s1_afv.sum()==0):
      return self.pattern_match_sim(val1,val2)
    sim = 1 - spatial.distance.cosine(s1_afv, s2_afv)
    return sim
    
##HELPER FUNCTION FOR PRINTING 
def pprint(o): 
    print(json.dumps(o, indent=2))

##TRAINING FUNCTION FOR RASA NLU
def Train(): 
  domain= "domain.yml"
  configuration = "config.yml"
  files = "data/"
  output = "models/"
  model_path = rasa.train(domain,configuration,[files],output)
  return model_path

##LOAD RASA INTERPRETER FOR TESTING
def Load_Interpreter(model_path): 
  model = get_validated_path(model_path, "model")
  model_path = get_model(model)
  _, nlu_model = get_model_subdirectories(model_path)
  return Interpreter.load(nlu_model)

##SPELL CHECK FEATURE FOR DID YOU MEAN ? 
def did_you_mean(query):
  flag=0
  data =  query.split()
  pattern = '\"\''
  new_data = []
  for word in data:
    if not re.search(pattern,word):
      new_data.append(spell.correction(word))
    else:
      new_data.append(word)

    if data!=new_data:
        flag=1
  return ' '.join(new_data),flag

##TESTING FUNCTION. WRITES RESULT TO "output.txt". INPUT FILE SHOULD HAVE ONE QUERY PER LINE. 
def test(interpreter, filename): 
    p = processing()
    outputfile = open("output.txt", "w")
    cnt=0
    with open(filename) as f:
        lines = f.readlines()
        for line in lines:
            cnt+=1
            corrected_line,f = did_you_mean(line)
            if (corrected_line!=line):
              print("Showing results for: " + corrected_line)
            rasa_out = interpreter.parse(line)
            intent, entities, tables = p.process(rasa_out)
            print(rasa_out)
            print("\n")
            print(entities)
            output = p.analyse(intent, entities, tables)        
            print(output)
            try:
              output = p.validate(intent, output)
              #print(output)
            except Exception as e:
              outputfile.write("Exception caught :"+str(e)+"\n") 
              continue
            output = JsonQuery(output['entities'],output['attr_count'],output['attributes'],output['attribute_values'],output['attr_types'],output['comparison_operators'], output['logical_operators'], output['return_attr'], output['orderflag'],output['order_attr'], output['limit'], output['pageval'])
            outputfile.write(output + "\n")
            print(cnt)

    
            
            
                  
##PROCESSING RASA OUTPUT USING SEMANTIC RULES AND HEURISTICS. VALIDATING THE QUERY AND RAISING EXCEPTIONS AS REQUIRED. 
class processing:
  def __init__(self):
    self.tables = {"customer", "product", "transaction"}
    self.attributes = {"customer_id", "customer_code" , "gender", "customer_name", "age" , "contact_number", "product_id", "price", "product_name","product_type","transaction_id","transaction_amount", "quantity", "transaction_date" }
    self.similarity = similarityChecker()

  def process(self, rasa_out): #seperates entities, intents and node names from rasa output so they can be sent to further processing
    intent = {}
    intent["name"] = rasa_out["intent"]["name"]
    entities = []
    tables = []
    prev = -1
    prev1 = -1
    sorted_rasa_entities = sorted(rasa_out["entities"], key = lambda x: (x["start"], -1*x["end"]))
    for entity in sorted_rasa_entities:
        dict = {}
        entity_name = entity["entity"]
        entity_value = entity["value"]
        start = entity["start"]
        end = entity["end"] 
        dict["entity"] =  entity_name.strip()
        dict["value"] = entity_value.strip()
        dict["start"] = start
        dict["end"] = end
        if (entity_name == "table_name"): 
          if (entity_value not in self.tables):
            _, entity_value = self.matchmostsimilarword(entity_value, self.tables)
            dict["value"] = entity_value
          tables.append(dict) 
        if (start==prev or end==prev1) or (abs(start-prev) ==1 or abs(end-prev1)==1):
            continue
        prev = start
        prev1 = end
        
        entities.append(dict)
    return intent, entities, tables

  def checkdate(self, string): #checks whether the string is date: dd/mm/yyyy, dd-mm-yyyy
    regex = '^([0]?[1-9]|[1|2][0-9]|[3][0|1])[./-]([0]?[1-9]|[1][0-2])[./-]([0-9]{4}|[0-9]{2})$'
    if re.match(regex, string):
      return True
    return False
  
  def checkstring(self,string): #checks whether string has only alphabets
    regex = "^[a-zA-Z\s]+$"
    if (re.match(regex,string)):
       return True
    return False
  
  def checknumber(self,string): #checks whether string has only numbers
    regex = '^[0-9]+$'
    if (re.match(regex,string)):
       return True
    return False
  
  def checkdouble(self,string): #checks whether string is a double 
    regex = '[+-]?[0-9]+\.*[0-9]*'
    if (re.match(regex,string)):
       return True
    return False

  def foreign_keys(self): #returns attribute names for each table
    Dict = { "Customer" : [], 
    "product" : [], 
    "transaction" :["customer_id","product_id"]  
    }
    return Dict
  
  def matchmostsimilarword(self, value, words):
    sim = 0
    result = ""
    for word in words:
      s = self.similarity.compute_similarity(value,word)
      if s > sim:
        sim = s
        result = word
    return sim, result
    
  def analyse(self, intent, entities, tables):

    # lists to be returned
    table_names = []
    condition_table_names = []
    attribute_count = 0
    attributes = []
    attribute_values = []
    comparison_operators = []
    logical_operators = []
    return_attributes = []
    order_flag = -1
    order_attributes = []
    limitval = -1
    pageval = -1

    # local variables for left to right parsing, much like english language works
    last_attribute = ""
    last_modifier = ""
    last_operator = ""
    last_table = ""
    direction = ""
    order_flg = -1
    last_attribute_start = -1
    page_flag = False
    condition_flag = False
    range_flag = -1
    limit_flag = False
    num_conditions = 0
    
    
    for i in range(len(entities)):
      e = entities[i]
      entity_name = e["entity"]
      entity_value = e["value"]

      if (entity_name == "quantity"): # limits the number of results
        if entity_value == "all":
            continue
        if self.checknumber(entity_value):
            limitval = entity_value

      if (entity_name == "table_name"): # identifies table names 
      #<table>'s <attribute1>,<attribute2>....... or <attribute> <proposition> <table>
        if (entity_value not in self.tables):
          _, last_table = self.matchmostsimilarword(entity_value, self.tables)
        else:
          last_table = entity_value
        if condition_flag:
          condition_table_names.append(last_table)
        else:
          table_names.append(last_table)

      if (entity_name == "value"): 
        print(entity_value)
        entity_value = re.sub("[\"\']", "", entity_value)
        if (limit_flag):
          limitval = entity_value
          limit_flag = False
        elif page_flag: #specifiying page value
          pageval = entity_value
          page_flag = False
        else:
          num_conditions = num_conditions + 1
          if ((len(logical_operators) +1)<num_conditions):
               logical_operators.append('&&')
          if (range_flag>-1 and range_flag<2):
            attribute_values.append(entity_value)
            range_flag = range_flag + 1
            continue
          elif entity_value.lower() == "male" or entity_value.lower() == "female" and last_attribute!="gender":
            comparison_operators.append("==")
            attributes.append("gender")
            attribute_values.append(entity_value.capitalize())
            continue
          elif (not condition_flag):
            return_attributes = return_attributes[:len(return_attributes)-1]
            condition_flag = True
          
          if (last_table!= '' and last_attribute in self.attribute_names()[last_table]):
              condition_table_names.append(last_table)

          if entity_value == "today" or entity_value == "yesterday" or self.checkdate(entity_value): 
          #Semantic rule: <attribute> <proposition> <date> or <noun> <verb> <proposition> <date> 
            

            if (last_attribute!="transaction_date" or last_table =="transaction"):  #dates can only be for transaction_dates
            #return_attributes.append("transaction_date")
              last_attribute = "transaction_date"
            attributes.append(last_attribute)
            if last_operator=="":                   # accounts for queries such as "before/after today, yesterday or date" etc.
              comparison_operators.append("==")
            else:
              comparison_operators.append(last_operator)
            last_operator = ""

            if entity_value == "today":
              today = date.today()
              d1 = today.strftime("%d/%m/%Y")
              attribute_values.append(d1)

            if entity_value == "yesterday":
              yesterday = datetime.now() - timedelta(1)
              yesterday = datetime.strftime(yesterday, '%d-%m-%Y')
              attribute_values.append(yesterday)

            if self.checkdate(entity_value):
              attribute_values.append(entity_value)
          
            if (last_attribute in self.attribute_names()[last_table]):
              condition_table_names.append(last_table)

          else: # Semantic rule: <attribute> <operator> <value> or <attribute> <value> or <attribute> <operator> <value> <conjuction> <operator> <value>
            if self.checkdouble(entity_value): 
            
              if (last_attribute=="" and last_table == "transaction") or (last_table == "transaction" and (last_attribute not in self.attribute_names()["transaction"] and last_attribute not in self.foreign_keys()["transaction"])):   # heuristic: if number indicates money, it needs to be mapped to transaction_amount or price depending on the last table
              #print(last_attribute in self.foreign_keys()["transaction"])
                last_attribute = "transaction_amount"
              elif (last_attribute=="" and last_table == "product") or (last_table == "product" and last_attribute not in self.attribute_names()["product"]):
                last_attribute = "price"
              
            if last_operator=="":  
              comparison_operators.append("==")
            else:
              comparison_operators.append(last_operator)

            last_operator = ""
            attribute_values.append(entity_value)
            attributes.append(last_attribute)
            
            
             
      if entity_name == "attribute": #checking attributes          
          if (entity_value not in self.attributes):
            if (entity_value in set(("type", "code", "name", "id"))):
              t = ""
              for table in tables:
                t = table["value"]
                if table["start"]>e["start"]: 
                  break
              print(t)
              _,last_attribute = self.matchmostsimilarword(entity_value, self.attribute_names()[t])
            else:
              _,last_attribute = self.matchmostsimilarword(entity_value, self.attributes)
          else:
            last_attribute = entity_value
          last_attribute_start = e["start"]
          if (order_flg>-1 and last_attribute_start > order_flg):
            order_attributes.append(last_attribute)
            order_flg = -1  
          elif not condition_flag:
            return_attributes.append(last_attribute)  

      if entity_name == "comparison": #checking comparison attributes

          last_operator = entity_value

      if entity_name == "logical_operator": #checking for logical operators such as and/or
  
          logical_operators.append(entity_value)

      if entity_name == "order": #checking order by
      # <order> <attribute> in <direction> or <attribute> in <direction>
          order_flag = 1
          order_flg = e["start"]

      if entity_name == "direction":
        if entity_value == "D":
          order_flag = 0
        else:
          order_flag = 1  
        if order_flg == -1:
          order_attributes.append(last_attribute)    

      if entity_name == "page":
        page_flag = True
      
      if entity_name == "split":
        condition_flag = True
      
      if entity_name == "limit":
        limit_flag = True
        
      if entity_name == "range" and entity_value == "from_to":
        range_flag = 0
        attributes.append(last_attribute)       
        attributes.append(last_attribute)
        comparison_operators.append(">")
        comparison_operators.append("<")
        logical_operators.append("&&")
      
    
    #if len(return_attributes)>1:  ## if there are more than one return attributes, then only return attributes will be different than order attributes. 
     # return_attributes = return_attributes[0:(len(return_attributes) - len(order_attributes))]
    #return_attributes = return_attributes[0:len(return_attributes) - (len(attributes))] # heuristic: attributes can either be associated with values or asked to be returned as user or specified for order 
    

    Dict = {
        'table_name': condition_table_names,
        'return_table_names': table_names, 
        'attribute': attributes,
        'values': attribute_values,
        'operators':comparison_operators,
        'logical_operator':logical_operators,
        'return_attributes':return_attributes,
        'orderflag':order_flag,
        'order_attr':order_attributes,
        'limit':limitval, 
        'pageval':pageval


    }
    return Dict
    
  def get_prop_node(self,attr):
    node=[]
    count = 0
    d = self.attribute_names()

    for i in d:
      if attr in d[i]:
        node.append(i)
        count+=1
    return node,count

  def get_condition(self,nodes,properties,operators,values,log): #assuming all nodes are there, number of elements in properties,operators,values are same
    n=len(nodes)
    m=len(properties)
    prop = [[] for i in range(n)]
    op = [[] for i in range(n)]
    val = [[] for i in range(n)]
    log_op = [[] for i in range(n)]
    j=0
    i=0
    cnt=0
    if len(operators)!=len(values):
      raise Exception("NO_VALUE_ERROR : Value not present.")
    while(i!=m):
      flag=0
      for j in range(n):
        if self.is_prop_of_node(properties[i],nodes[j]):
          prop[j].append(properties[i])
          op[j].append(operators[i])
          val[j].append(values[i])
          cnt+=1
          if(cnt>0 and len(log)>0):
            log_op[j].append(log[i-1])
          flag=1
          break
      i+=1
      if flag==0:
        raise Exception("Atribute cant be mapped to node name")

    attr_count = [len(k) for k in prop]
    return prop,val,op,attr_count,log_op

  def get_all_nodes(self,nodes,prop,ret_attr):
      for i in ret_attr+prop:
        l,cnt = self.get_prop_node(i)
        #print(l,cnt,i)
        if cnt==1:
          if l[0] not in nodes:
            if i in ret_attr:
              t = [l[0]]
              nodes = t+nodes
              print("Added return table name...",l[0],"WARNING: MISSING TABLE NAME OR WRONG ATTRIBUTE USED")
            else:
              nodes.append(l[0])
              print("Added table name...",l[0],"WARNING: MISSING TABLE NAME OR WRONG ATTRIBUTE USED")
            
        elif cnt>1:
          present = 0
          for j in l:
            if j in nodes:
              present=1
              break
          if present!=1:
            raise Exception("ERROR!!!MISSING TABLE NAME AND ATTRIBUTE FOUND IN MULTIPLE TABLE")
            return None
      return nodes

  def is_prop_of_node(self,prop,node):
      p = self.attribute_names()
      return prop in p[node]

  
  def get_return_attrs(self,nodes,r_attrs,r_nodes):
      return_attrs = [[] for i in range(len(nodes)) ]
      r_attrs = self.remove_dup(r_attrs)
      for i in range(len(nodes)):
        for j in r_attrs:
          if self.is_prop_of_node(j,nodes[i]):
            return_attrs[i].append(j)
      for i in range(1,len(nodes)):
        if return_attrs[i]==[]:
          if nodes[i] in r_nodes:
            return_attrs[i].append('*')
      return return_attrs 

  def get_order_attrs(self,nodes,o_attrs):
      o_attrs = self.remove_dup(o_attrs)
      order_attrs = [[] for i in range(len(nodes)) ]
      for i in range(len(nodes)):
        for j in o_attrs:
          if self.is_prop_of_node(j,nodes[i]):
            order_attrs[i].append(j)

      return order_attrs 
      
  
  def node_names(self):
    return ["customer","product","transaction"]

  def attribute_names(self): #returns attribute names for each table
    Dict = {
        "customer": ["customer_id", "customer_code" , "gender", "customer_name", "age" , "contact_number"],
        "product": ["product_id", "price", "product_name","product_type"],
        "transaction":["transaction_id", "transaction_amount", "quantity", "transaction_date"]
        }
    return Dict

  def attribute_types(self):
    d = {
        "customer_name":"STRING",
        "address":"STRING",
        "contact_details":"STRING",
        "gender":"STRING",
        "contact_number":"NUMBER",
         "age":"INTEGER",
         "birthdate":"DATE",
         "customer_id":"INTEGER",
         "customer_code":"STRING",
         "product_id":"STRING", 
         "product_name":"STRING",
         "product_type":"STRING",
         "transaction_amount":"DOUBLE",
         "transaction_date":"DATE",
         "quantity":"INTEGER",
         "price":"DOUBLE",
         "transaction_id":"INTEGER"
    }
    return d


  def typecheck(self, attribute, value,t):
    typ = self.attribute_types()[attribute]
    if typ=="INTEGER":
      return self.checknumber(value)
    if typ=="STRING":
      return self.checkstring(value)
    if typ=="DOUBLE":
      return self.checkdouble(value)
    if type=="DATE":
      return self.checkdate(value)
  
  def get_logic_op(self,oper):
    return oper

  def get_type(self,attr):
    l = []
    d = self.attribute_types()
    for i in attr:
      k=[]
      for j in i:
        k.append(d[j])
      l.append(k)
    return l

  def remove_dup(self,l):
    temp = []
    for i in l:
      if i not in temp:
        temp.append(i)
    return temp

  def check_valid_table(self,nodes,attr):
    if nodes==[]:
      return True
    for i in attr:
      flag=0
      for j in nodes:
        if self.is_prop_of_node(i,j):
          flag=1
        if flag==1:
          break

  def get_date(self,d):
    date=''
    l = d.split('.')
    if(len(l)!=3):
      l = d.split('/')
    if(len(l)!=3):
      l= d.split('-')

    if(len(l)==3):
      if len(l[2])==2:
        date='20'+l[2]
      else:
        date=l[2]
      date+='-'
      if len(l[1])==1:
        date+='0'+l[1]
      else:
        date+=l[1]
      date+='-'
      if len(l[0])==1:
        date+='0'+l[0]
      else:
        date+=l[0]
    else:
      raise Exception("DATE CANT BE COMVERTED !")
    return date
  def validate(self, intent, entity):

    query = {}
    query['entities'] = []
    query['properties'] = []
    query['attributes'] = []
    query['attribute_values'] = []
    query['attr_count'] = -1
    query['comparison_operators'] = []
    query['logical_operators'] = []
    #query['return_attributes'] = []
    query['attr_types'] = []
    query['limit'] = -1
    query['orderflag'] = -1
    query['order_attr'] = []
    query['pageval'] = -1 
    query['count'] = -1
    if intent["name"]=="simple_query" or intent["name"]=="conditional_query" or 1==1:
      
      attribute =""
      entity['return_attributes'] = self.remove_dup(entity['return_attributes'])
      query['entities'] = entity['table_name'] #self.match_node(entity_value)
      tables = entity['return_table_names'] #self.match_node(entity['return_tables'])
      query['entities']=tables + query['entities']
      query['entities'] = self.remove_dup(query['entities'])
      tables = entity['table_name']
      #print(query['entities'])
      if 'attribute' in entity:
            
        query['properties'] =entity["attribute"] #self.match_property(entity_value)
        entity['return_attributes'] = entity['return_attributes'] #self.match_property(entity['return_attributes'])
        
        s = self.check_valid_table(tables,entity['attribute'])

        query['entities'] = self.get_all_nodes(query['entities'],query['properties']+entity['return_attributes'],entity['return_attributes'])
        #print(query['entities'])
        query['entities'] = self.remove_dup(query['entities'])

        query['attributes'],query['attribute_values'],query['comparison_operators'],query['attr_count'],query['logical_operators'] = self.get_condition(query['entities'],query['properties'],entity['operators'],entity['values'],entity['logical_operator'])
        query['attr_types'] = self.get_type(query['attributes'])

        match = True
        for i in range(len(query['attributes'])):
          for j in range(len(query['attributes'][i])):
            match = self.typecheck(query['attributes'][i][j],query['attribute_values'][i][j],query['attr_types'][i][j])
            #print(match,query['attr_types'][i],query['attribute_values'][i])
            if match == False:
              raise Exception("TYPE ERROR : "+query['attr_types'][i][j]+" is Expected")
            if query['attr_types'] == 'DATE':
              query['attribute_values'] = self.get_date(query['attribute_values'])
      query['return_attr'] = self.get_return_attrs(query['entities'],entity['return_attributes'],entity['return_table_names'])

         
    query['limit'] = int(entity['limit'])
    query['orderflag'] = entity['orderflag']
    query['order_attr'] = self.get_order_attrs(query['entities'],entity['order_attr'])
    query['pageval'] = int(entity['pageval'])

    if query['orderflag']!=-1:
      found = 0
      for ii in query['order_attr']:
        if ii!=[]:
          found=1
      if found==0:
        raise Exception("No_ORDER_ATTR: No Order attribute mentioned. ") 
    if query['limit']==0:
      raise Exception("LIMIT_ZERO_ERROR : LIMIT CANT BE ZERO.")

    if query['pageval']>0 and query['limit']<0:
      raise Exception("PAGE_WITHOUT_LIMIT : Paging used without Limit")

    if 'count' in entity:
      query['count'] = 1
    for i in range(len(query['entities'])):
      query['entities'][i] = query['entities'][i].capitalize()


    return query

def JsonQuery(entities,attributecount,attributes,attributevalues,attributetypes,operators,logicaloperators,returnattributes,orderflag,orderattributes,limitval,pagevalue):
  
  output="$."+entities[0]
  if(len(attributecount)>0):
    output+=""
  flag=0
  for en in range(0,len(entities)):
    if(en>0):
      if(attributecount[en]>0):
        if(flag==1):
          output+="&&"
    for attrs in range(0,attributecount[en]):
      if(flag==0):
        output+="[?("
      flag=1
      if(attrs>0):
        output+=logicaloperators[en][attrs-1]
      output+="@."
      if(en>0):
        output=output+entities[en]+"."
      output+=attributes[en][attrs]
      output+=operators[en][attrs]
      if(attributetypes[en][attrs]=="STRING" or attributetypes[en][attrs]=="DATE"):
        output=output+"'"+attributevalues[en][attrs]+"'"
      else:
        output+=attributevalues[en][attrs]
      
  if flag==0:
    output+="[]"
  else:
    output+=")]"
  if(len(returnattributes)>0):
    for en in range(0,len(entities)):
      if(len(returnattributes[en])>0):
        if(en>0):
            output=output+"&expands="+entities[en]
        if(returnattributes[en][0] != "*"):
          output=output+"&fields="+entities[en]+":"
          for atrs in range(0,len(returnattributes[en])):
            if(atrs>0):
              output+=","
            output+=returnattributes[en][atrs]
        
          
      
  if(orderflag>-1):
    output+="&sort="
    for en in range(0,len(entities)):
      for atrs in range(0,len(orderattributes[en])):
        if(atrs>0):
          output+=","
        output=output+entities[en]+":"+orderattributes[en][atrs]
    if(orderflag==1):
      output+=",A"
    else:
      output+=",D"
  if(limitval>-1):
    output=output+"&limit="+str(limitval)
  if(pagevalue>-1):
    if(limitval>-1):
      output=output+"&page="+str(pagevalue)
    else:
      raise Exception("Error:Page has been mentioned without limit")
      
  return output

def json_mapper(j):

  print("USER QUERY : ",j['text'],"\n")
  p1 = processing()
  intent,enti,tables = p1.process(j)
  print(enti)
  e = p1.analyse(intent,enti,tables)
  print(e)
  query = p1.validate(intent,e)
  
  print("\n\n\n",query)
  s = JsonQuery(query['entities'],query['attr_count'],query['attributes'],query['attribute_values'],query['attr_types'],query['comparison_operators'],query['logical_operators'],query['return_attr'],query['orderflag'],query['order_attr'],query['limit'],query['pageval'])
  return e,query,s

def parse(query):
  try:
      print("parsing...")
      j = nlu_interpreter.parse(query)
      print(j)
      q1,q,s = json_mapper(j)
      return q1,q,s
  except Exception as ex:
      print(ex)
      s=ex
      q={'error':-1}
      q1={'error':-1}
      return q1,q,s

nlu_interpreter = Load_Interpreter('nlu-20210618-093623.tar.gz')#('nlu-20210606-014331.tar.gz')#('D:\\NLtoJSON\\models\\nlu-20210607-085809.tar.gz')
print('\nInterpreter loaded')
test(nlu_interpreter,"testqueries.txt")


#test(nlu_interpreter,'testqueries.txt')
"""
while(True):
  try:
    query  = input("PLS ENTER :")
    j = nlu_interpreter.parse(query)
    print(j)
    s = json_mapper(j)
    print("",s)

    except Exception as ex:
    print(ex)
    print("An exception occurred")
  pass"""

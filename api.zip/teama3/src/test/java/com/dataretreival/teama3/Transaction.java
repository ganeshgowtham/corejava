package com.dataretreival.teama3;

public class Transaction {

}

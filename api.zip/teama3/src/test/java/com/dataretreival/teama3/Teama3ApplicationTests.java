package com.dataretreival.teama3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Teama3ApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.dataretreival.teama3;
// Generated from JsonPath.g4 by ANTLR 4.7.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link JsonPathParser}.
 */
public interface JsonPathListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link JsonPathParser#jsonpath}.
	 * @param ctx the parse tree
	 */
	void enterJsonpath(JsonPathParser.JsonpathContext ctx);
	/**
	 * Exit a parse tree produced by {@link JsonPathParser#jsonpath}.
	 * @param ctx the parse tree
	 */
	void exitJsonpath(JsonPathParser.JsonpathContext ctx);
	/**
	 * Enter a parse tree produced by {@link JsonPathParser#dotnotation}.
	 * @param ctx the parse tree
	 */
	void enterDotnotation(JsonPathParser.DotnotationContext ctx);
	/**
	 * Exit a parse tree produced by {@link JsonPathParser#dotnotation}.
	 * @param ctx the parse tree
	 */
	void exitDotnotation(JsonPathParser.DotnotationContext ctx);
	/**
	 * Enter a parse tree produced by {@link JsonPathParser#dotnotation_expr}.
	 * @param ctx the parse tree
	 */
	void enterDotnotation_expr(JsonPathParser.Dotnotation_exprContext ctx);
	/**
	 * Exit a parse tree produced by {@link JsonPathParser#dotnotation_expr}.
	 * @param ctx the parse tree
	 */
	void exitDotnotation_expr(JsonPathParser.Dotnotation_exprContext ctx);
	/**
	 * Enter a parse tree produced by {@link JsonPathParser#identifierWithQualifier}.
	 * @param ctx the parse tree
	 */
	void enterIdentifierWithQualifier(JsonPathParser.IdentifierWithQualifierContext ctx);
	/**
	 * Exit a parse tree produced by {@link JsonPathParser#identifierWithQualifier}.
	 * @param ctx the parse tree
	 */
	void exitIdentifierWithQualifier(JsonPathParser.IdentifierWithQualifierContext ctx);
	/**
	 * Enter a parse tree produced by {@link JsonPathParser#mfunction}.
	 * @param ctx the parse tree
	 */
	void enterMfunction(JsonPathParser.MfunctionContext ctx);
	/**
	 * Exit a parse tree produced by {@link JsonPathParser#mfunction}.
	 * @param ctx the parse tree
	 */
	void exitMfunction(JsonPathParser.MfunctionContext ctx);
	/**
	 * Enter a parse tree produced by {@link JsonPathParser#function}.
	 * @param ctx the parse tree
	 */
	void enterFunction(JsonPathParser.FunctionContext ctx);
	/**
	 * Exit a parse tree produced by {@link JsonPathParser#function}.
	 * @param ctx the parse tree
	 */
	void exitFunction(JsonPathParser.FunctionContext ctx);
	/**
	 * Enter a parse tree produced by {@link JsonPathParser#query_expr}.
	 * @param ctx the parse tree
	 */
	void enterQuery_expr(JsonPathParser.Query_exprContext ctx);
	/**
	 * Exit a parse tree produced by {@link JsonPathParser#query_expr}.
	 * @param ctx the parse tree
	 */
	void exitQuery_expr(JsonPathParser.Query_exprContext ctx);
}
package com.dataretreival.teama3;
import java.util.Arrays;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Vector;

public class SQLquery {
    String query = "";
    String matchQuery = " FROM ";
    String whereQuery = "";
    String returnQuery = "SELECT ";
    boolean firstWhere = true;
    String joinQuery= " ";
    String parentEntity = "";
    Vector<String> matchString = new Vector<String>();
    Vector<String> returnString = new Vector<String>();
    Vector<String> joinVector = new Vector<String>();

    private String[] Customer = {"customer_id","customer_code", "gender", "customer_name", "age", "contact_number","birthdate"};
    private String[] Transaction = {"transaction_id", "transaction_amount","customer_id","id","quantity","transaction_date"};
    private String[] Product = {"id","product_id", "product_name", "price", "product_type"};

    Dictionary<Object,Object> entityDictionary = new Hashtable<Object,Object>(){{
        put("Customer","Customer");
        put("Transaction","Transaction");
        put("Product","Product");
    }};

    public void addToMatch(String inputMatchString){
        matchQuery += entityDictionary.get(inputMatchString);
        returnString.add(String.valueOf(entityDictionary.get(inputMatchString).toString())+".*");
        parentEntity = inputMatchString;
    }

    public void join(String entities[])
    {
        System.out.println("Checking");
        System.out.println(entities.length);
        if(parentEntity.contains("Transaction")){
            System.out.println("In");
            for(int m = 0; m< joinVector.size();m++){
                if(joinVector.get(m).contains(entities[0])){
                    return;
                }
            }

        }else{
            System.out.println("Parent Entity : " + parentEntity);
            if( parentEntity.contains("Customer") ){
                System.out.println("Came in else");
                if(joinVector.contains("Product") || joinVector.contains(entities[0])){
                    System.out.println("reached 0");
                    return;
                }
                if(entities[0].contains("Product")){
                    System.out.println("reached 1");
                    System.out.println(joinVector.contains("Transaction"));
                    if(joinVector.contains("Transaction")){
                        System.out.println("appending...");
                        joinVector.add("Product");
                        joinQuery += "INNER JOIN Product ON Transaction.id = Product.id";
                        return;
                    }
                }
            }
            if(parentEntity.contains("Product") ){
                System.out.println("Came in else else");
                if(joinVector.contains("Customer") || joinVector.contains(entities[0])){
                    System.out.println("reached 2");
                    return;
                }
                if(entities[0].contains("Customer")){
                    System.out.println("Came here");
                    if(joinVector.contains("Transaction")){
                        System.out.println("appending...");
                        joinVector.add("Customer");
                        joinQuery += "INNER JOIN Customer ON Transaction.customer_id = Customer.customer_id";
                        return;
                    }
                }
            }
        }
        joinVector.add(entities[0]);
        System.out.println("Printing Join");
        System.out.println(parentEntity);
        for(int j=0;j<entities.length;j++){
            System.out.println(entities[j]);
        }

        if(entities.length == 2)
        {
            if(parentEntity.equals("Customer"))
            {
                entities[0] = "Product";
                entities[1] = "Transaction";
            }
            else if(parentEntity.equals("Product"))
            {
                entities[0] = "Customer";
                entities[1] = "Transaction";
            }
        }
        for(int iterator = 0; iterator < entities.length ; iterator++)
        {
            String attribute="";
            switch(parentEntity)
            {
                case "Customer":if(entities[iterator].equals("Product"))
                                {
                                    joinQuery += "INNER JOIN Transaction ON Customer.customer_id = Transaction.customer_id INNER JOIN Product ON Transaction.id = Product.id ";
                                    return ;
                                }
                                else if(entities[iterator].equals("Transaction"))
                                {
                                    for (int secondIterator=0; secondIterator< Transaction.length ; secondIterator++)
                                    {
                                        if (Arrays.asList(Customer).contains(Transaction[secondIterator]))
                                        {
                                            attribute=Transaction[secondIterator];
                                            break;
                                        }
                                    }
                                }
                                break;
                case "Product": if(entities[iterator].equals("Customer"))
                                {
                                    joinQuery += "INNER JOIN Transaction ON Transaction.id = Product.id INNER JOIN Customer ON Customer.customer_id = Transaction.customer_id ";
                                    return ;
                                }
                                else if(entities[iterator].equals("Transaction"))
                                {
                                    for (int secondIterator=0; secondIterator< Transaction.length;secondIterator++)
                                        {
                                        if (Arrays.asList(Product).contains(Transaction[secondIterator]))
                                        {
                                            attribute=Transaction[secondIterator];
                                            break;
                                        }
                                    }
                                }
                                break;
                case "Transaction": switch(entities[iterator]){
                    case "Customer": for (int secondIterator=0; secondIterator< Transaction.length;secondIterator++)
                    {
                        if (Arrays.asList(Customer).contains(Transaction[secondIterator])){
                            attribute=Transaction[secondIterator];
                            break;
                        }
                    }
                    break;
                    case "Product": for (int secondIterator=0; secondIterator< Transaction.length;secondIterator++)
                    {
                        if (Arrays.asList(Product).contains(Transaction[secondIterator])){
                            attribute=Transaction[secondIterator];
                            break;
                        }
                    }
                    break;
                }
                break;
            }
            if (attribute!="")
                joinQuery+= "INNER JOIN "+ entities[iterator] + " ON " + parentEntity + "." + attribute + "=" + entities[iterator] + "." + attribute + " ";
        }
    }

    public void addToWhere(String inputWhereString){

        if (inputWhereString == ""){
            return;
        }

        int index_1= 0;
        int index_2 = 0;
        if(firstWhere){
            whereQuery += " WHERE ";
            firstWhere = false;
        }
        inputWhereString = inputWhereString.substring(1);
        boolean hasReached = false;
        for(int iterator = 1; iterator < inputWhereString.length() ; iterator++){
            char testChar = inputWhereString.charAt(iterator);
            if(!((Character.isLetter(testChar))  || testChar == '.' || testChar == '\'' || Character.isDigit(testChar)|| testChar=='_')) {
                if(!hasReached){
                    index_1 = iterator;
                }
                hasReached = true;
            }else{
                if(hasReached){
                    index_2 = iterator;
                    break;
                }
            }
        }

        String entities = inputWhereString.substring(0,index_1);
        String operator = inputWhereString.substring(index_1,index_2);
        String value = inputWhereString.substring(index_2);

        String[] entitiesArray = entities.split("\\.");
        String attribute = entitiesArray[entitiesArray.length -1];
        entitiesArray = Arrays.copyOfRange(entitiesArray, 1, entitiesArray.length -1);

        String oneChar = "";
        if(entitiesArray.length == 0){
            oneChar = String.valueOf(entityDictionary.get(parentEntity).toString());
        }else{
            oneChar = String.valueOf(entityDictionary.get(entitiesArray[entitiesArray.length - 1]).toString());
            join(entitiesArray);
        }
        
        whereQuery += " " + oneChar + "." + attribute;

        if(operator.equals("*==*"))
        {
            value = "%" + value.substring(1,value.length()-1) + "%";
            whereQuery += " LIKE "+ "'" + value + "'";
        }
        else if(operator.equals("=*"))
        {
            value = "%" + value.substring(1,value.length()-1);
            whereQuery += " LIKE "+ "'" + value + "'";
        }
        else if(operator.equals("*="))
        {
            value = value.substring(1,value.length()-1) + "%";
            whereQuery += " LIKE "+ "'" + value + "'";
        }
        else if(operator.equals("=="))
        {
            whereQuery += " = " + value;
        }
        else
        {
            whereQuery += operator + value;
        }
    }

    public void addToReturn(String inputReturnString){

        int stopFlag = inputReturnString.indexOf('.');
        if (stopFlag != -1)
        {
            if(returnString.contains(String.valueOf(inputReturnString.substring(0, stopFlag+1)+"*"))){
                returnString.remove(String.valueOf(inputReturnString.substring(0, stopFlag+1)+"*"));
            }
            returnString.add(inputReturnString);
        }
        else
        {
            if(returnString.contains(String.valueOf(inputReturnString))){
                returnString.remove(String.valueOf(inputReturnString));
            }
            returnString.add(inputReturnString+".*");
        }
    }

    public void addAnd() {
        whereQuery += " AND";
    }
    public void addOr() {
        whereQuery += " OR";
    }

    public String printfinal(){

        returnQuery += String.join(",",returnString);
        String finalQuery = returnQuery+ matchQuery+joinQuery+whereQuery+";";
        return finalQuery;
    }

    public void addEnd(String inputEndString){
        whereQuery += " " + inputEndString;
    }
}

package com.dataretreival.teama3;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MySqlData {
    Connection conn;
    public MySqlData(String url, String user, String pass) throws SQLException {
        conn= DriverManager.getConnection(url,user, pass);
    }

    public List<FinalSQLdata> execute(String Query) throws SQLException {
        try (Statement stmt = conn.createStatement();){


            ResultSet rs = stmt.executeQuery(Query);
            ResultSetMetaData rsmd = rs.getMetaData();
            List<FinalSQLdata> out = new ArrayList<FinalSQLdata>();
            while (rs.next()) {
                FinalSQLdata currec = new FinalSQLdata();
                for (int column = 1; column <= rsmd.getColumnCount(); column++) {
                    if (rsmd.getColumnName(column).equals("customer_id")) {
                        currec.setCustomer_id(rs.getInt(column));
                    }

                    if (rsmd.getColumnName(column).equals("customer_code")) {
                        currec.setCustomer_code(rs.getString(column));
                    }
                    if (rsmd.getColumnName(column).equals("gender")) {
                        currec.setGender(rs.getString(column));
                    }
                    if (rsmd.getColumnName(column).equals("contact_number")) {
                        currec.setContact_number(rs.getString(column));
                    }
                    if (rsmd.getColumnName(column).equals("age")) {
                        currec.setAge(rs.getInt(column));
                    }
                    if (rsmd.getColumnName(column).equals("id")) {
                        currec.setId(rs.getInt(column));
                    }
                    if (rsmd.getColumnName(column).equals("product_id")) {
                        currec.setProduct_id(rs.getString(column));
                    }
                    if (rsmd.getColumnName(column).equals("birthdate")) {
                        currec.setBirthdate(rs.getString(column));
                    }
                    if (rsmd.getColumnName(column).equals("customer_name")) {
                        currec.setCustomer_name(rs.getString(column));
                    }
                    if (rsmd.getColumnName(column).equals("transaction_id")) {
                        currec.setTransaction_id((float) rs.getInt(column));
                    }
                    if (rsmd.getColumnName(column).equals("transaction_amount")) {
                        currec.setTransaction_amount(rs.getFloat(column));
                    }
                    if (rsmd.getColumnName(column).equals("quantity")) {
                        currec.setQuantity(rs.getFloat(column));
                    }
                    if (rsmd.getColumnName(column).equals("transaction_date")) {
                        currec.setTransaction_date(rs.getString(column));
                    }
                    if (rsmd.getColumnName(column).equals("product_name")) {
                        currec.setProduct_name(rs.getString(column));
                    }
                    if (rsmd.getColumnName(column).equals("product_type")) {
                        currec.setProduct_type(rs.getString(column));
                    }
                    if (rsmd.getColumnName(column).equals("price")) {
                        currec.setPrice(rs.getFloat(column));
                    }


                }
                out.add(currec);
            }
            return out;
        } finally {

        }
    }
    }


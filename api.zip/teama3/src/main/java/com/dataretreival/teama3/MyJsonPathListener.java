package com.dataretreival.teama3;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import java.util.Arrays;
import org.antlr.v4.runtime.ParserRuleContext;
import java.util.Vector;


import java.util.regex.Pattern;

public class MyJsonPathListener extends JsonPathBaseListener
{
    QueryGen queryGenObject;
    boolean firstWhere = true;

    private String temporaryString ="";
    private String temporaryString_2 = "";
    private String temporaryString_3 = "";
    private String temporaryString_4 = "";
    
    private String[] s1 = {"Customer",  "Transaction", "MADE"};
    private String[] s2 = {"Customer",  "Product", "PURCHASED"};
    private String[] s3 = {"Transaction", "Product", "PROCESSED"};


    private String[] Customer = {"customer_id", "customer_code", "gender", "customer_name", "age", "contact_number","birthdate"};
    private String[] Transaction = {"transaction_id", "transaction_amount", "quantity", "transaction_date"};
    private String[] Product = {"product_id", "product_name", "price", "product_type"};

    private String outputstring = "";

    MyJsonPathListener()
    {
     queryGenObject = new QueryGen();
    }

    public  String getQuery(){
        return  outputstring;
    }


    @Override public void enterJsonpath(JsonPathParser.JsonpathContext context) {
        System.out.println(context.getText());
    }

    @Override public void enterEveryRule(ParserRuleContext context) {
    }

    @Override public void enterIdentifierWithQualifier(JsonPathParser.IdentifierWithQualifierContext context) {
        String identifierString = context.getText();
        String bracketIndex = String.valueOf("\\[");
        String[] arrstring = identifierString.split(bracketIndex);
        if(context.IDENTIFIER() != null)
        {
            String identifier = context.IDENTIFIER().toString();
            queryGenObject.addToMatch(identifier);
        }
        else
        {
            queryGenObject.addToMatch("");
        }

    }

    @Override public void enterQuery_expr(JsonPathParser.Query_exprContext context) {
        String[] queries = context.getText().split("&&");
        boolean isFirstQuery = true;
        if(firstWhere)
        {
            firstWhere = false;
        }
        else
        {
            return;
        }

        for(int iterator = 0; iterator < queries.length ; iterator++)
        {
            String[] subQueries = queries[iterator].split(Pattern.quote("||"));
            boolean andFirstFlag = true;
            for(int secondIterator = 0; secondIterator < subQueries.length; secondIterator++)
            {
                if(!isFirstQuery)
                {
                    if(andFirstFlag)
                    {
                        queryGenObject.addAnd();
                        andFirstFlag = false;
                    }
                    else
                    {
                        queryGenObject.addOr();
                    }
                }else{
                    isFirstQuery = false;
                }
                //System.out.println(subQueries[secondIterator]);
                queryGenObject.addToWhere(subQueries[secondIterator]);
            }
        }

    }
    @Override public void enterFunction(JsonPathParser.FunctionContext context) {
//        System.out.println("Function");
//        System.out.println(context.getText());

    }


@Override
    public void exitMfunction(JsonPathParser.MfunctionContext context) {


        String functionString = context.getText().toString();
        //System.out.println(functionString);
        String functionSplit[] = functionString.split("&");
        String functions[] = Arrays.copyOfRange(functionSplit, 1,  functionSplit.length);
        //System.out.println(Arrays.asList(functions));
        for(int iterator = 0; iterator < functions.length; iterator++)
        {
            
            if (functions[iterator].contains("expands")) 
            {
                //System.out.println("expands : ");
                //System.out.println(functions[iterator]);
                String expandsAttributes = functions[iterator].replace("expands","");
                expandsAttributes = expandsAttributes.replace(" ","");
                expandsAttributes = expandsAttributes.replace("=","");
                String[] attributes = expandsAttributes.split(",");
                for(int secondIterator=0; secondIterator < attributes.length ; secondIterator++)
                {
                    queryGenObject.expandMatch(attributes[secondIterator]);
                    if (attributes[secondIterator].equals("Customer")){
                        queryGenObject.addToReturn("n");
                    }
                    else if (attributes[secondIterator].equals("Transaction")){
                        queryGenObject.addToReturn("m");
                    } 
                    else if (attributes[secondIterator].equals("Product")){
                        queryGenObject.addToReturn("o");
                    }
                }

            }

            else if (functions[iterator].contains("fields"))
            {
                String fieldsString = functions[iterator].substring(functions[iterator].indexOf("=") + 1, functions[iterator].length());
                String fieldsAttributes[] = fieldsString.split(":");
                String fieldsAttributesSplit[] = fieldsAttributes[1].split(",");
                
                //System.out.println(Arrays.asList(fieldsString));
                
                for(int thirdIterator = 0; thirdIterator < fieldsAttributesSplit.length ; thirdIterator++)
                {
                    if (fieldsAttributes[0].equals("Customer"))
                    {
                        temporaryString += "n." + fieldsAttributesSplit[thirdIterator] +",";
                        queryGenObject.addToReturn("n." + fieldsAttributesSplit[thirdIterator]);
                    }
                    else if (fieldsAttributes[0].equals("Transaction"))
                    {
                        temporaryString += "m." + fieldsAttributesSplit[thirdIterator] +",";
                        queryGenObject.addToReturn("m." + fieldsAttributesSplit[thirdIterator]);

                    }
                    else if (fieldsAttributes[0].equals("Product"))
                    {
                        temporaryString += "o." + fieldsAttributesSplit[thirdIterator] +",";
                        queryGenObject.addToReturn("o." + fieldsAttributesSplit[thirdIterator]);
                    }
                }
            }
        
            else if(functions[iterator].contains("sort"))
            {
                String sortString = "";
                if(functions[iterator].indexOf(",")>-1)
                    sortString = functions[iterator].substring(functions[iterator].indexOf(":")+1, functions[iterator].indexOf(","));
                else
                    sortString = functions[iterator].substring(functions[iterator].indexOf(":")+1,functions[iterator].length());
                char parentNode ='\0';
                if(Arrays.asList(Customer).contains(sortString))
                {
                    parentNode = 'n';
                }
                else if(Arrays.asList(Transaction).contains(sortString))
                {
                    parentNode = 'm';
                }
                else if(Arrays.asList(Product).contains(sortString))
                {
                    parentNode = 'o';
                }
                //temporaryString_2 += "\n";
                temporaryString_4 += " ORDER BY " + parentNode + "."+ sortString + " " ;
                String descFlag = functions[iterator].substring(functions[iterator].indexOf(",")+1, functions[iterator].length());
                if(descFlag.equals("D"))
                { 
                    temporaryString_4 += " DESC" + " ";
                }

            }

            else if(functions[iterator].contains("limit"))
            {
                temporaryString_2 += " LIMIT " + functions[iterator].substring(functions[iterator].indexOf("=")+1, functions[iterator].length() ) +" ";
            }

            else if(functions[iterator].contains("page"))
            {
                String pageNumber = functions[iterator].substring(functions[iterator].indexOf("=")+1, functions[iterator].length());
                String pageLimit = new String();
                for(int secondIterator = iterator-1; secondIterator >= 0; secondIterator--)
                {
                    if(functions[secondIterator].contains("limit"))
                    {
                        pageLimit = functions[secondIterator].substring(functions[secondIterator].indexOf("=")+1, functions[secondIterator].length());
                        break;    
                    }
                    
                }
                int skipValue = Integer.valueOf(pageNumber)*Integer.valueOf(pageLimit)-Integer.valueOf(pageLimit);
                temporaryString_3 += " SKIP " + skipValue + " ";

            }
        } 
	}

    @Override public void exitJsonpath(JsonPathParser.JsonpathContext context) {
        outputstring += queryGenObject.printFinal();
        outputstring +=temporaryString_4 + temporaryString_3 +  temporaryString_2;
//        queryGenObject.printFinal();
//	    System.out.println(temporaryString_2);
    }
}

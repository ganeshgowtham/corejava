package com.dataretreival.teama3;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.time.LocalDate;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"customer_name","age","gender","birthdate","contact_number","customer_code","customer_id","transactions","products"})
public class Customer {
    private LocalDate birthdate;
    private String Gender;
    private String customer_name;
    private Float customer_id;
    private String customer_code;
    private Float age;
    private Long contact_number;


    Transaction transactions;
    Product products;


    public void setGender(String gender) {
        this.Gender = gender;
    }
    public LocalDate getBirthdate() {
        return birthdate;
    }

    public String getGender() {
        return Gender;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public Float getCustomer_id() {
        return customer_id;
    }

    public String getCustomer_code() {
        return customer_code;
    }
    public Float getAge() {
        return age;
    }

    public void setAge(Float age) {
        this.age = age;
    }


    public void setBirthdate(LocalDate birthdate) {
        this.birthdate = birthdate;
    }



    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public void setCustomer_id(Float customer_id) {
        this.customer_id = customer_id;
    }

    public void setCustomer_code(String customer_code) {
        this.customer_code = customer_code;
    }
    public Long getContact_number() {
        return contact_number;
    }

    public void setContact_number(Long contact_number) {
        this.contact_number = contact_number;
    }


    public Transaction getTransactions() {
        return transactions;
    }

    public Product getProducts() {
        return products;
    }

    public void setTransactions(Transaction transactions) {
        this.transactions = transactions;
    }

    public void setProducts(Product products) {
        this.products = products;
    }

}

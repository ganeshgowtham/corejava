package com.dataretreival.teama3;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.HandlerMapping;

import java.io.IOException;

@RestController
public class Controller {


    String FinalJsonPath;

    @Bean
    public WebServerFactoryCustomizer<TomcatServletWebServerFactory>
    containerCustomizer(){
        return new EmbeddedTomcatCustomizer();
    }

    private static class EmbeddedTomcatCustomizer implements WebServerFactoryCustomizer<TomcatServletWebServerFactory> {

        @SuppressWarnings("deprecation")
        @Override
        public void customize(TomcatServletWebServerFactory factory) {
            factory.addConnectorCustomizers((TomcatConnectorCustomizer) connector -> {
                connector.setAttribute("relaxedPathChars", "<>[\\]^`{|}?");
                connector.setAttribute("relaxedQueryChars", "<>[\\]^`{|}?");
            });
        }
    }
    @GetMapping("/")
    public String queryoutput1() {
        return "Welcome to Team A3's API server Type /fetchdata/[neo4j or mysql]/[result or query]/[JSONPath query]  to get output";
    }

    @RequestMapping("fetchdata/neo4j/query/**")
    public String searchWithSearchTerm(HttpServletRequest request) throws IOException {
        // Don't repeat a pattern
        String pattern = (String)
                request.getAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE);

        String JSONPath = new AntPathMatcher().extractPathWithinPattern(pattern,
                request.getServletPath());

        int ind = JSONPath.indexOf('[')+1;

        String FinJSONPath=JSONPath.substring(0,ind)+"?"+JSONPath.substring(ind);


        String CypherQuery = Query.returnQuery(FinJSONPath,0);
        System.out.println(CypherQuery);

        return CypherQuery;
    }
    @RequestMapping("fetchdata/mysql/query/**")
    public String searchWithSearchTerm1(HttpServletRequest request) throws IOException {
        // Don't repeat a pattern
        String pattern = (String)
                request.getAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE);
        String JSONPath = new AntPathMatcher().extractPathWithinPattern(pattern,
                request.getServletPath());
        int ind = JSONPath.indexOf('[')+1;
        String FinJSONPath=JSONPath.substring(0,ind)+"?"+JSONPath.substring(ind);


        String SQLQuery = Query.returnQuery(FinJSONPath,1).replace("Transaction","Transactions");
        System.out.println(SQLQuery);

        return SQLQuery;
    }
    @RequestMapping("/fetchdata/neo4j/result/**")
    public FinalData searchWithSearchTerm2(HttpServletRequest request) throws Exception {

        String pattern = (String)
                request.getAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE);
        String JSONPath = new AntPathMatcher().extractPathWithinPattern(pattern,
                request.getServletPath());
        int ind = JSONPath.indexOf('[')+1;

        String FinJSONPath=JSONPath.substring(0,ind)+"?"+JSONPath.substring(ind);
        String CypherQuery = Query.returnQuery(FinJSONPath,0);
        System.out.println(CypherQuery);

        try (Neo4jData sample = new Neo4jData("bolt://localhost:7687", "neo4j", "12345");){

            FinalData output;
            output = sample.execute1(CypherQuery, FinJSONPath);
            return output;
        }
    }
    @RequestMapping("/fetchdata/mysql/result/**")
    public List<FinalSQLdata> searchWithSearchTerm3(HttpServletRequest request) throws IOException, SQLException {

        String pattern = (String)
                request.getAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE);
        String JSONPath = new AntPathMatcher().extractPathWithinPattern(pattern,
                request.getServletPath());
        int ind = JSONPath.indexOf('[')+1;
        String FinJSONPath=JSONPath.substring(0,ind)+"?"+JSONPath.substring(ind);
        String SQLQuery = Query.returnQuery(FinJSONPath,1).replace("Transaction","Transactions");


        System.out.println(SQLQuery);
        MySqlData sample = new MySqlData("jdbc:mysql://localhost:3306/CustomerDetails","root","1234567q!ASD");
        List<FinalSQLdata> output;
        output=sample.execute(SQLQuery);

        return output;
    }


}

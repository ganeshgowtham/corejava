package com.dataretreival.teama3;

import org.neo4j.driver.*;
import org.neo4j.driver.Record;

import java.util.ArrayList;
import java.util.List;

public class Neo4jData implements AutoCloseable {
    private final Driver driver;

    public Neo4jData(String uri, String user, String password) {
        driver = GraphDatabase.driver(uri, AuthTokens.basic(user, password));
    }

    @Override
    public void close() throws Exception {
        driver.close();
    }

    public int findIndex(String arr[], String sr){
        for(int i=0;i<3;i++){
            if(arr[i].equals(sr)){
                return i;
            }
        }
        return -1;
    }

    public FinalData execute1(String query,String Json) {
        String tablenames[]={"Customer","Transaction","Product"};
        String Nodenames[]={"n","m","o"};
        Session session = driver.session();
        Result result = session.run(query);

        System.out.println(result.keys());
        String BaseNodeName=Json.substring(2,Json.indexOf('['));
        String BaseNode= Nodenames[findIndex(tablenames,BaseNodeName)];

        List<Customer> customers=new ArrayList<Customer>();
        List<Transaction> transactions=new ArrayList<Transaction>();
        List<Product> products=new ArrayList<Product>();



        List<Record> results= result.list();
        for (Record record : results) {

            Customer customerObject=null;Transaction transactionObject=null; Product productObject=null;

            int nflag=0,mflag=0,oflag=0; //n,m,o being the nodenames
            for(int recorditerator = 0; recorditerator <record.size(); recorditerator++) {
                if (result.keys().get(recorditerator).length() == 1) {

                    Value rec = record.get(recorditerator);
                    if(result.keys().get(recorditerator).equals("n")) {
                        customerObject=new Customer();
                        for (String key : rec.keys()) {
                            if( key.equals("birthdate")){
                                customerObject.setBirthdate(rec.get(key).asLocalDate());
                            }
                            if( key.equals("gender")){
                                customerObject.setGender(rec.get(key).asString());
                            }
                            if( key.equals("customer_name")){
                                customerObject.setCustomer_name(rec.get(key).asString());
                            }
                            if( key.equals("customer_id")){
                                customerObject.setCustomer_id(rec.get(key).asFloat());
                            }
                            if( key.equals("customer_code")){
                                customerObject.setCustomer_code(rec.get(key).asString());
                            }
                            if( key.equals("age")){
                                customerObject.setAge(rec.get(key).asFloat());
                            }
                            if( key.equals("contact_number")){
                                customerObject.setContact_number(rec.get(key).asLong());
                            }
                        }
                    }
                    if(result.keys().get(recorditerator).equals("m")) {
                        transactionObject=new Transaction();
                        for (String key : rec.keys()) {
                            if( key.equals("quantity")){
                                transactionObject.setQuantity(rec.get(key).asFloat());
                            }
                            if( key.equals("transaction_amount")){
                                transactionObject.setTransaction_amount(rec.get(key).asFloat());
                            }
                            if( key.equals("transaction_date")){
                                transactionObject.setTransaction_date(rec.get(key).asLocalDate());
                            }
                            if( key.equals("transaction_id")){
                                transactionObject.setTransaction_id(rec.get(key).asFloat());
                            }

                        }
                    }
                    if(result.keys().get(recorditerator).equals("o")) {
                        productObject=new Product();
                        for (String key : rec.keys()) {
                            if( key.equals("id")){
                                productObject.setId(rec.get(key).asFloat());
                            }
                            if( key.equals("price")){
                                productObject.setPrice(rec.get(key).asFloat());
                            }
                            if( key.equals("product_name")){
                                productObject.setProduct_name(rec.get(key).asString());
                            }
                            if( key.equals("product_id")){
                                productObject.setProduct_id(rec.get(key).asString());
                            }


                        }
                    }

                }
                else if(result.keys().get(recorditerator).length() > 1){
                    if(result.keys().get(recorditerator).substring(0,1).equals("n")){
                        if(nflag==0){
                            customerObject=new Customer();
                            nflag=1;
                        }
                        if(result.keys().get(recorditerator).equals("n.birthdate")){
                            customerObject.setBirthdate(record.get("n.birthdate").asLocalDate());
                        }
                        if(result.keys().get(recorditerator).equals("n.gender")){
                            customerObject.setGender(record.get("n.gender").asString());
                        }
                        if(result.keys().get(recorditerator).equals("n.customer_name")){
                            customerObject.setCustomer_name(record.get("n.customer_name").asString());
                        }
                        if(result.keys().get(recorditerator).equals("n.customer_id")){
                            customerObject.setCustomer_id(record.get("n.customer_id").asFloat());
                        }
                        if(result.keys().get(recorditerator).equals("n.customer_code")){
                            customerObject.setCustomer_code(record.get("n.customer_code").asString());
                        }
                        if(result.keys().get(recorditerator).equals("n.age")){
                            customerObject.setAge(record.get("n.age").asFloat());
                        }
                        if(result.keys().get(recorditerator).equals("n.contact_number")){
                            customerObject.setContact_number(record.get("n.contact_number").asLong());
                        }


                    }
                    if(result.keys().get(recorditerator).substring(0,1).equals("m")){
                        if(mflag==0){
                            transactionObject=new Transaction();
                            mflag=1;
                        }
                        if(result.keys().get(recorditerator).equals("m.quantity")){
                            transactionObject.setQuantity(record.get("m.quantity").asFloat());
                        }
                        if(result.keys().get(recorditerator).equals("m.transaction_amount")){
                            transactionObject.setTransaction_amount(record.get("m.transaction_amount").asFloat());
                        }
                        if(result.keys().get(recorditerator).equals("m.transaction_date")){
                            transactionObject.setTransaction_date(record.get("m.transaction_date").asLocalDate());
                        }
                        if(result.keys().get(recorditerator).equals("m.transaction_id")){
                            transactionObject.setTransaction_id(record.get("m.transaction_id").asFloat());
                        }



                    }
                    if(result.keys().get(recorditerator).substring(0,1).equals("o")){
                        if(oflag==0){
                            productObject=new Product();
                            oflag=1;
                        }
                        if(result.keys().get(recorditerator).equals("o.id")){
                            productObject.setId(record.get("o.id").asFloat());
                        }
                        if(result.keys().get(recorditerator).equals("o.price")){
                            productObject.setPrice(record.get("o.price").asFloat());
                        }
                        if(result.keys().get(recorditerator).equals("o.product_id")){
                            productObject.setProduct_id(record.get("o.product_id").asString());
                        }
                        if(result.keys().get(recorditerator).equals("o.product_name")){
                            productObject.setProduct_name(record.get("o.product_name").asString());
                        }



                    }
                }
            }
            if(BaseNode.equals("n")){
                customerObject.setTransactions(transactionObject);
                customerObject.setProducts(productObject);
                customers.add(customerObject);
            }
            if(BaseNode.equals("m")){
                transactionObject.setCustomers(customerObject);
                transactionObject.setProducts(productObject);
                transactions.add(transactionObject);
            }
            if(BaseNode.equals("o")){
                productObject.setTransactions(transactionObject);
                productObject.setCustomers(customerObject);
                products.add(productObject);
            }



        }
        FinalData output=new FinalData();
        if(BaseNode.equals("n")){
        output.setCustomers(customers);}
        if(BaseNode.equals("m")){
            output.setTransactions(transactions);}
        if(BaseNode.equals("o")){
            output.setProducts(products);}

        return output;
    }

}
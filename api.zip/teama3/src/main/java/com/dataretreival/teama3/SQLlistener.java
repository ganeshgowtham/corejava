package com.dataretreival.teama3;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.TerminalNode;

import java.util.Arrays;
import java.util.Stack;
import java.util.regex.Pattern;

public class SQLlistener implements JsonPathListener{
    SQLquery gen;
    boolean firstWhere= true;
    private String temporaryString ="";

    private String[] Customer = {"customer_id","customer_code", "gender", "customer_name", "age", "contact_number","birthdate"};
    private String[] Transaction = {"transaction_id", "transaction_amount","customer_id","product_id","quantity","transaction_date"};
    private String[] Product = {"product_id", "product_name", "price", "product_type"};


    private String outputstring = "";

    SQLlistener(){
        gen = new SQLquery();}

    public String getQuery(){
        return outputstring;
    }

    @Override public void enterJsonpath(JsonPathParser.JsonpathContext ctx) {
        System.out.println(ctx.getText());
    }

    @Override public void enterIdentifierWithQualifier(JsonPathParser.IdentifierWithQualifierContext ctx) {
        String identifierString = ctx.getText();
        String bracketIndex = String.valueOf("\\[");
        String[] arrayString = identifierString.split(bracketIndex);
        String identifier = ctx.IDENTIFIER().toString();
        gen.addToMatch(identifier);
    }

    @Override public void enterQuery_expr(JsonPathParser.Query_exprContext ctx) {
        String[] queries = ctx.getText().split("&&");
        boolean isFirstQuery = true;
        if(firstWhere){
            firstWhere = false;
        }else{
            return;
        }

        for(int iterator = 0;iterator < queries.length ; iterator++){
            String[] subQueries = queries[iterator].split(Pattern.quote("||"));
            boolean andFirstFlag = true;
            for(int secondIterator = 0; secondIterator < subQueries.length ; secondIterator++){
                if(!isFirstQuery){
                    if(andFirstFlag){
                        gen.addAnd();
                        andFirstFlag = false;
                    }else{
                        gen.addOr();
                    }
                }else{
                    isFirstQuery = false;
                }
                gen.addToWhere(subQueries[secondIterator]);
            }
        }

    }

    @Override
    public void exitMfunction(JsonPathParser.MfunctionContext ctx) {

        // int flag=0;
        String functionString = ctx.getText().toString();
        String functionSplit[] = functionString.split("&");
        String functions[] = Arrays.copyOfRange(functionSplit, 1,  functionSplit.length);
        for(int iterator = 0 ; iterator < functions.length ; iterator++)
        {

            if (functions[iterator].contains("expands")) {
                String expandsAttributes = functions[iterator].replace("expands","");
                expandsAttributes = expandsAttributes.replace(" ","");
                expandsAttributes = expandsAttributes.replace("=","");
                String[] attributes = expandsAttributes.split(",");
                gen.join(attributes);
                gen.addToReturn(attributes[0]);
            }

            else if (functions[iterator].contains("fields")){
                String fieldsString = functions[iterator].substring(functions[iterator].indexOf("=") + 1, functions[iterator].length());
                String fieldsAttributes[] = fieldsString.split(":");
                String fieldsAttributesSplit[] = fieldsAttributes[1].split(",");

                for(int secondIterator = 0 ; secondIterator < fieldsAttributesSplit.length ; secondIterator++){
                    if (fieldsAttributes[0].equals("Customer")){
                        temporaryString += "n." + fieldsAttributesSplit[secondIterator] +",";
                        gen.addToReturn(fieldsAttributes[0]+"."+ fieldsAttributesSplit[secondIterator]);
                    }
                    else if (fieldsAttributes[0].equals("Transaction")){
                        temporaryString += "m." + fieldsAttributesSplit[secondIterator] +",";
                        gen.addToReturn(fieldsAttributes[0]+"." + fieldsAttributesSplit[secondIterator]);

                    }
                    else if (fieldsAttributes[0].equals("Product")){
                        temporaryString += "o." + fieldsAttributesSplit[secondIterator] +",";
                        gen.addToReturn(fieldsAttributes[0]+"." + fieldsAttributesSplit[secondIterator]);
                    }
                }
            }

            else
            {
                if(functions[iterator].contains("sort")){
                    String sortString = "";
                    if(functions[iterator].indexOf(",")>-1)
                    sortString = functions[iterator].substring(functions[iterator].indexOf(":")+1, functions[iterator].indexOf(","));
                    else
                        sortString = functions[iterator].substring(functions[iterator].indexOf(":")+1,functions[iterator].length());
                    String temporaryString_2 = "";
                    String parentNode = "";
                    if(Arrays.asList(Customer).contains(sortString))
                    {
                        parentNode = "Customer";
                    }
                    else if(Arrays.asList(Product).contains(sortString))
                    {
                        parentNode = "Product";
                    }
                    else if(Arrays.asList(Transaction).contains(sortString))
                    {
                        parentNode = "Transaction";
                    }
                    temporaryString_2 += "ORDER BY " + parentNode + "."+ sortString ;
                    String descFlag = functions[iterator].substring(functions[iterator].indexOf(",")+1, functions[iterator].length());
                    if(descFlag.equals("D"))
                    {
                       temporaryString_2 += " DESC";
                    }
                    gen.addEnd(temporaryString_2);
                }

                else if(functions[iterator].contains("limit")){
                    String temporaryString_3 = "";
                    if(iterator+1 < functions.length){
                        if (functions[iterator+1].contains("page"))
                        {
                            String pageNumber = functions[iterator+1].substring(functions[iterator+1].indexOf("=")+1, functions[iterator+1].length());
                            String pageLimit = functions[iterator].substring(functions[iterator].indexOf("=")+1, functions[iterator].length());
                            int skipValue = Integer.valueOf(pageNumber)*Integer.valueOf(pageLimit)-Integer.valueOf(pageLimit);
                            temporaryString_3 += "LIMIT " + Integer.valueOf(pageLimit) + " OFFSET "+ skipValue ;
                        }
                    }
                    else
                        temporaryString_3 += "LIMIT " + functions[iterator].substring(functions[iterator].indexOf("=")+1, functions[iterator].length() ) +" ";
                    gen.addEnd(temporaryString_3);
                }
            }
        }
    }

    @Override public void exitJsonpath(JsonPathParser.JsonpathContext ctx) {
        outputstring += gen.printfinal();
    }
    
    @Override public void enterEveryRule(ParserRuleContext ctx) {
    }
    
    @Override public void enterFunction(JsonPathParser.FunctionContext ctx) {
    }
    
    @Override
    public void enterDotnotation(JsonPathParser.DotnotationContext ctx) {

    }

    @Override
    public void exitDotnotation(JsonPathParser.DotnotationContext ctx) {

    }

    @Override
    public void enterDotnotation_expr(JsonPathParser.Dotnotation_exprContext ctx) {

    }

    @Override
    public void exitDotnotation_expr(JsonPathParser.Dotnotation_exprContext ctx) {

    }

    @Override
    public void exitIdentifierWithQualifier(JsonPathParser.IdentifierWithQualifierContext ctx) {

    }

    @Override
    public void enterMfunction(JsonPathParser.MfunctionContext ctx) {

    }

    @Override
    public void exitFunction(JsonPathParser.FunctionContext ctx) {

    }

    @Override
    public void exitQuery_expr(JsonPathParser.Query_exprContext ctx) {

    }

    @Override
    public void visitTerminal(TerminalNode terminalNode) {

    }

    @Override
    public void visitErrorNode(ErrorNode errorNode) {

    }

    @Override
    public void exitEveryRule(ParserRuleContext parserRuleContext) {

    }
}

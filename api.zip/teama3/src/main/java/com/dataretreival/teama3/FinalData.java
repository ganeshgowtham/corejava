package com.dataretreival.teama3;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FinalData {
    List<Customer> customers;
    List<Transaction> transactions;
    List<Product> products;

    public List<Customer> getCustomers() {
        return customers;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }

    public void setTransactions(List<Transaction> transactions) {
        this.transactions = transactions;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }
}

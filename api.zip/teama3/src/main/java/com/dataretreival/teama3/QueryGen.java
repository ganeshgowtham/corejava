package com.dataretreival.teama3;
import org.antlr.v4.runtime.misc.Pair;

import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;


import java.util.Arrays;

public class QueryGen {
    //static String query = "";
    String matchQuery = "MATCH ";
    String whereQuery = "";
    String returnQuery = " RETURN ";
    boolean firstWhere = true;
    String parentEntity = "";
    Vector<String> matchString = new Vector<String>();
    Vector<String> returnString = new Vector<String>();



    Dictionary<Object,Object> entityDictionary = new Hashtable<Object,Object>(){{
        put("Customer","(n: Customer)");
        put("Transaction","(m: Transaction)");
        put("Product","(o: Product)");
    }};
    Dictionary<Pair<Object,Object>,Object> relationDictionary = new Hashtable<Pair<Object,Object>,Object>(){{
        put(new Pair<Object,Object>("Customer","Transaction"),"[r: Made]");
        put(new Pair<Object,Object>("Customer","Product"),"[b: Purchased]");
        put(new Pair<Object,Object>("Transaction","Product"),"[g: Processed]");
        put(new Pair<Object,Object>("Transaction","Customer"),"[r: MadeBy]");
        put(new Pair<Object,Object>("Product","Customer"),"[b: PurchasedBy]");
        put(new Pair<Object,Object>("Product","Transaction"),"[g: ProcessedBy]");

    }};


    public void addToMatch(String inputString){
        if(inputString == ""){
            Enumeration<Object> values = entityDictionary.elements();
            String temporaryString = values.nextElement().toString();
            matchQuery += temporaryString;
            returnString.add(String.valueOf(temporaryString.charAt(1)));
            while( values.hasMoreElements() ){
                temporaryString = values.nextElement().toString();
                matchQuery += "," + temporaryString;
                returnString.add(String.valueOf(temporaryString.charAt(1)));
            }

        }else {
            matchQuery += entityDictionary.get(inputString);
//        returnQuery+= entityDictionary.get(inputString).toString().charAt(1);
            returnString.add(String.valueOf(entityDictionary.get(inputString).toString().charAt(1)));
            parentEntity = inputString;
        }
    }

    public void appendToMatch(String[] inputString){
            String temporaryQuery = ", ";
            temporaryQuery += entityDictionary.get(parentEntity).toString() + "-" + relationDictionary.get(new Pair<Object,Object>(parentEntity, inputString[0].toString())).toString() + "->" +entityDictionary.get(inputString[0].toString()).toString();
            for(int iterator = 0; iterator < inputString.length -1 ; iterator++){
                temporaryQuery+= "-" + relationDictionary.get(new Pair<Object,Object>(inputString[iterator].toString(),inputString[iterator+1].toString())).toString() + "->" +entityDictionary.get(inputString[iterator+1].toString()).toString();
            }
            if(!matchString.contains(temporaryQuery)){
                matchQuery += temporaryQuery;
                matchString.add(temporaryQuery);
            }
    }

    public void expandMatch(String newEntity){
        String entityString = entityDictionary.get(newEntity).toString();
        if(!matchQuery.contains(entityString)){
            matchQuery +="," + entityDictionary.get(parentEntity).toString() + "-" + relationDictionary.get(new Pair<Object,Object>(parentEntity,newEntity)).toString() + "->" +entityString;
            addToReturn(String.valueOf(relationDictionary.get(new Pair<Object,Object>(parentEntity,newEntity)).toString().charAt(1)));
        }
    }

    public void addToWhere(String inputString){
//        System.out.println(inputString);
        if(inputString == ""){
            return;
        }
        if(firstWhere){
            whereQuery += " WHERE ";
            firstWhere = false;
        }
        int index_1 = 0;
        int index_2 = 0;
        inputString = inputString.substring(1);
        boolean hasReached = false;
        for(int iterator = 1; iterator < inputString.length() ; iterator++){
		char testChar = inputString.charAt(iterator);
            if(!((Character.isLetter(testChar))  || testChar == '.' || testChar == '\'' || Character.isDigit(testChar)|| testChar=='_')) {
                if(!hasReached){
                    index_1 = iterator;
                }
                hasReached = true;
            }else{
                if(hasReached){
                   index_2 = iterator;
                   break;
                }
            }
        }
	// System.out.println(index_1);    
	// System.out.println(index_2);
        String entities = inputString.substring(0,index_1);
        String operator = inputString.substring(index_1,index_2);
        String value = inputString.substring(index_2);

        String[] entitiesArray = entities.split("\\.");
        String attribute = entitiesArray[entitiesArray.length - 1];
        entitiesArray = Arrays.copyOfRange(entitiesArray, 1, entitiesArray.length-1 );

        String oneChar = "";
        if(entitiesArray.length == 0){
            oneChar = String.valueOf(entityDictionary.get(parentEntity).toString().charAt(1));
        }else{
            oneChar = String.valueOf(entityDictionary.get(entitiesArray[entitiesArray.length - 1]).toString().charAt(1));
            appendToMatch(entitiesArray);
        }

        whereQuery += " " + oneChar + "." + attribute;
        if(attribute.equals("transaction_date"))
        {
            value = "date(" + value + ")";
        }
        if(attribute.equals("birthdate"))
        {
            value = "date(" + value + ")";
        }
        if(operator.equals("*==*"))
        {
            whereQuery += " CONTAINS " + value;
        }
        else if(operator.equals("=*"))
        {
            whereQuery += " ENDS WITH " + value;
        }
        else if(operator.equals("*="))
        {
            whereQuery += " STARTS WITH " + value;
        }
        else if(operator.equals("!="))
        {
            whereQuery += " <> " + value;
        }
        else if(operator.equals("=="))
		{
			whereQuery += " = " + value;  
		} 
        else
        {
            whereQuery += operator + value;
        }
		//System.out.println(whereQuery);
    }

    public void addToReturn(String inputString){
        if(returnString.contains(String.valueOf(inputString.charAt(0)))){
            returnString.remove(String.valueOf(inputString.charAt(0)));
        }
        returnString.add(inputString);
    }

    public void addAnd() {
        whereQuery += " AND ";
    }
    public void addOr() {
        whereQuery += " OR ";
    }

    public String printFinal(){

        returnQuery += String.join(",",returnString);
        String returnString = matchQuery + whereQuery + returnQuery;
        System.out.println(returnQuery);
        return returnString;
    }

	public void printReturnQuery(){
        System.out.println(returnQuery);
    }


}

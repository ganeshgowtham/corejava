package com.dataretreival.teama3;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import java.io.IOException;
import java.io.*;

 import static org.antlr.v4.runtime.CharStreams.fromFileName;
import java.util.Scanner;

public class Query {
    public static String returnQuery(String a,int choice) throws IOException {


        System.out.println("reached here");

        CharStream cs = new ANTLRInputStream(a);//load the file
       JsonPathLexer lexer = new JsonPathLexer(cs);  //instantiate a lexer
       CommonTokenStream tokens = new CommonTokenStream(lexer); //scan stream for tokens
       JsonPathParser parser = new JsonPathParser(tokens);  //parse the tokens

        ParseTree tree = parser.jsonpath(); // parse the content and get the tree



       switch(choice)
       {
           case 0:
           //System.out.println("CYPHER QUERY:");
           MyJsonPathListener listener = new MyJsonPathListener();
           ParseTreeWalker walker1 = new ParseTreeWalker();
           walker1.walk(listener,tree);
           return listener.getQuery();

           case 1:
           SQLlistener sqllistener = new SQLlistener();
           ParseTreeWalker walker = new ParseTreeWalker();
           walker.walk(sqllistener,tree);
           return sqllistener.getQuery();

          default: System.out.println("Wrong input");
       }
       return  "Invalid input";
    }
}

package com.dataretreival.teama3;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"id","product_name","price","product_id","transactions","customers"})
public class Product {
    private Float id;
    private String product_name;
    private Float price;
    private String product_id;
    Transaction transactions;
    Customer customers;

    public Float getId() {
        return id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public Float getPrice() {
        return price;
    }

    public String getProduct_id() {
        return product_id;
    }




    public void setId(Float id) {
        this.id = id;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public Transaction getTransactions() {
        return transactions;
    }

    public void setTransactions(Transaction transactions) {
        this.transactions = transactions;
    }

    public Customer getCustomers() {
        return customers;
    }

    public void setCustomers(Customer customers) {
        this.customers = customers;
    }
}

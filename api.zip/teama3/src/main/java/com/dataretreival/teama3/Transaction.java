package com.dataretreival.teama3;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.time.LocalDate;
import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"transaction_id","quantity","transaction_amount","transaction_date","customers","products"})
public class Transaction {
    private Float transaction_id;
    private LocalDate transaction_date;
    private Float quantity;
    private Float transaction_amount;
    Customer customers;
    Product products;

    public void setTransaction_id(Float transaction_id) {
        this.transaction_id = transaction_id;
    }

    public Float getTransaction_id() {
        return transaction_id;
    }

    public LocalDate getTransaction_date() {
        return transaction_date;
    }

    public Float getQuantity() {
        return quantity;
    }

    public Float getTransaction_amount() {
        return transaction_amount;
    }



    public void setTransaction_date(LocalDate transaction_date) {
        this.transaction_date = transaction_date;
    }

    public void setQuantity(Float quantity) {
        this.quantity = quantity;
    }

    public void setTransaction_amount(Float transaction_amount) {
        this.transaction_amount = transaction_amount;
    }

    public Customer getCustomers() {
        return customers;
    }

    public void setCustomers(Customer customers) {
        this.customers = customers;
    }

    public Product getProducts() {
        return products;
    }

    public void setProducts(Product products) {
        this.products = products;
    }
}

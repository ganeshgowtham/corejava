// Generated from /Users/mohammedmukarram/IdeaProjects/teama3/src/main/java/com/dataretreival/teama3/JsonPath.g4 by ANTLR 4.9.1
package com.dataretreival.teama3;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link JsonPathParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface JsonPathVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link JsonPathParser#jsonpath}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJsonpath(JsonPathParser.JsonpathContext ctx);
	/**
	 * Visit a parse tree produced by {@link JsonPathParser#dotnotation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDotnotation(JsonPathParser.DotnotationContext ctx);
	/**
	 * Visit a parse tree produced by {@link JsonPathParser#dotnotation_expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDotnotation_expr(JsonPathParser.Dotnotation_exprContext ctx);
	/**
	 * Visit a parse tree produced by {@link JsonPathParser#identifierWithQualifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifierWithQualifier(JsonPathParser.IdentifierWithQualifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link JsonPathParser#mfunction}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMfunction(JsonPathParser.MfunctionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JsonPathParser#function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction(JsonPathParser.FunctionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JsonPathParser#query_expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuery_expr(JsonPathParser.Query_exprContext ctx);
}
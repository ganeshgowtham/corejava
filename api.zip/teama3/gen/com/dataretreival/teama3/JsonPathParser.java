// Generated from /Users/mohammedmukarram/IdeaProjects/teama3/src/main/java/com/dataretreival/teama3/JsonPath.g4 by ANTLR 4.9.1
package com.dataretreival.teama3;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class JsonPathParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.9.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, T__14=15, T__15=16, T__16=17, 
		T__17=18, T__18=19, T__19=20, T__20=21, T__21=22, T__22=23, T__23=24, 
		T__24=25, T__25=26, T__26=27, T__27=28, INDENTIFIER=29, INTEGER=30, WHITE_SPACE=31;
	public static final int
		RULE_jsonpath = 0, RULE_dotnotation = 1, RULE_dotnotation_expr = 2, RULE_identifierWithQualifier = 3, 
		RULE_mfunction = 4, RULE_function = 5, RULE_query_expr = 6;
	private static String[] makeRuleNames() {
		return new String[] {
			"jsonpath", "dotnotation", "dotnotation_expr", "identifierWithQualifier", 
			"mfunction", "function", "query_expr"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'$.'", "'[]'", "'['", "']'", "'[?('", "')]'", "'&'", "'='", "':'", 
			"','", "'&&'", "'||'", "'*'", "'@.'", "'.'", "'==''", "'''", "'=='", 
			"'>='", "'<='", "'>'", "'<'", "'!='", "'@.length-'", "'!=''", "'*==*''", 
			"'*=''", "'=*''"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, "INDENTIFIER", "INTEGER", "WHITE_SPACE"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "JsonPath.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public JsonPathParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class JsonpathContext extends ParserRuleContext {
		public DotnotationContext dotnotation() {
			return getRuleContext(DotnotationContext.class,0);
		}
		public JsonpathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonpath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JsonPathListener ) ((JsonPathListener)listener).enterJsonpath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JsonPathListener ) ((JsonPathListener)listener).exitJsonpath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JsonPathVisitor ) return ((JsonPathVisitor<? extends T>)visitor).visitJsonpath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonpathContext jsonpath() throws RecognitionException {
		JsonpathContext _localctx = new JsonpathContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_jsonpath);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(14);
			dotnotation();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DotnotationContext extends ParserRuleContext {
		public List<Dotnotation_exprContext> dotnotation_expr() {
			return getRuleContexts(Dotnotation_exprContext.class);
		}
		public Dotnotation_exprContext dotnotation_expr(int i) {
			return getRuleContext(Dotnotation_exprContext.class,i);
		}
		public List<MfunctionContext> mfunction() {
			return getRuleContexts(MfunctionContext.class);
		}
		public MfunctionContext mfunction(int i) {
			return getRuleContext(MfunctionContext.class,i);
		}
		public DotnotationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dotnotation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JsonPathListener ) ((JsonPathListener)listener).enterDotnotation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JsonPathListener ) ((JsonPathListener)listener).exitDotnotation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JsonPathVisitor ) return ((JsonPathVisitor<? extends T>)visitor).visitDotnotation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DotnotationContext dotnotation() throws RecognitionException {
		DotnotationContext _localctx = new DotnotationContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_dotnotation);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(16);
			match(T__0);
			setState(17);
			dotnotation_expr();
			setState(21);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__1 || _la==INDENTIFIER) {
				{
				{
				setState(18);
				dotnotation_expr();
				}
				}
				setState(23);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(27);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__6) {
				{
				{
				setState(24);
				mfunction();
				}
				}
				setState(29);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Dotnotation_exprContext extends ParserRuleContext {
		public IdentifierWithQualifierContext identifierWithQualifier() {
			return getRuleContext(IdentifierWithQualifierContext.class,0);
		}
		public TerminalNode INDENTIFIER() { return getToken(JsonPathParser.INDENTIFIER, 0); }
		public Dotnotation_exprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dotnotation_expr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JsonPathListener ) ((JsonPathListener)listener).enterDotnotation_expr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JsonPathListener ) ((JsonPathListener)listener).exitDotnotation_expr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JsonPathVisitor ) return ((JsonPathVisitor<? extends T>)visitor).visitDotnotation_expr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Dotnotation_exprContext dotnotation_expr() throws RecognitionException {
		Dotnotation_exprContext _localctx = new Dotnotation_exprContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_dotnotation_expr);
		try {
			setState(32);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(30);
				identifierWithQualifier();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(31);
				match(INDENTIFIER);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IdentifierWithQualifierContext extends ParserRuleContext {
		public TerminalNode INDENTIFIER() { return getToken(JsonPathParser.INDENTIFIER, 0); }
		public TerminalNode INTEGER() { return getToken(JsonPathParser.INTEGER, 0); }
		public Query_exprContext query_expr() {
			return getRuleContext(Query_exprContext.class,0);
		}
		public IdentifierWithQualifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identifierWithQualifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JsonPathListener ) ((JsonPathListener)listener).enterIdentifierWithQualifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JsonPathListener ) ((JsonPathListener)listener).exitIdentifierWithQualifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JsonPathVisitor ) return ((JsonPathVisitor<? extends T>)visitor).visitIdentifierWithQualifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdentifierWithQualifierContext identifierWithQualifier() throws RecognitionException {
		IdentifierWithQualifierContext _localctx = new IdentifierWithQualifierContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_identifierWithQualifier);
		try {
			setState(46);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,3,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(34);
				match(INDENTIFIER);
				setState(35);
				match(T__1);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(36);
				match(INDENTIFIER);
				setState(37);
				match(T__2);
				setState(38);
				match(INTEGER);
				setState(39);
				match(T__3);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(40);
				match(INDENTIFIER);
				setState(41);
				match(T__4);
				setState(42);
				query_expr(0);
				setState(43);
				match(T__5);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(45);
				match(T__1);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MfunctionContext extends ParserRuleContext {
		public List<FunctionContext> function() {
			return getRuleContexts(FunctionContext.class);
		}
		public FunctionContext function(int i) {
			return getRuleContext(FunctionContext.class,i);
		}
		public MfunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mfunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JsonPathListener ) ((JsonPathListener)listener).enterMfunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JsonPathListener ) ((JsonPathListener)listener).exitMfunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JsonPathVisitor ) return ((JsonPathVisitor<? extends T>)visitor).visitMfunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MfunctionContext mfunction() throws RecognitionException {
		MfunctionContext _localctx = new MfunctionContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_mfunction);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(48);
			function();
			setState(52);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(49);
					function();
					}
					} 
				}
				setState(54);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FunctionContext extends ParserRuleContext {
		public List<TerminalNode> INDENTIFIER() { return getTokens(JsonPathParser.INDENTIFIER); }
		public TerminalNode INDENTIFIER(int i) {
			return getToken(JsonPathParser.INDENTIFIER, i);
		}
		public TerminalNode INTEGER() { return getToken(JsonPathParser.INTEGER, 0); }
		public FunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JsonPathListener ) ((JsonPathListener)listener).enterFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JsonPathListener ) ((JsonPathListener)listener).exitFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JsonPathVisitor ) return ((JsonPathVisitor<? extends T>)visitor).visitFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FunctionContext function() throws RecognitionException {
		FunctionContext _localctx = new FunctionContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_function);
		int _la;
		try {
			setState(87);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(55);
				match(T__6);
				setState(56);
				match(INDENTIFIER);
				setState(57);
				match(T__7);
				setState(58);
				match(INTEGER);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(59);
				match(T__6);
				setState(60);
				match(INDENTIFIER);
				setState(61);
				match(T__7);
				setState(62);
				match(INDENTIFIER);
				setState(63);
				match(T__8);
				setState(67);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==INDENTIFIER) {
					{
					{
					setState(64);
					match(INDENTIFIER);
					}
					}
					setState(69);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(74);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__9) {
					{
					{
					setState(70);
					match(T__9);
					setState(71);
					match(INDENTIFIER);
					}
					}
					setState(76);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(77);
				match(T__6);
				setState(78);
				match(INDENTIFIER);
				setState(79);
				match(T__7);
				setState(80);
				match(INDENTIFIER);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(81);
				match(T__6);
				setState(82);
				match(INDENTIFIER);
				setState(83);
				match(T__7);
				setState(84);
				match(INDENTIFIER);
				setState(85);
				match(T__9);
				setState(86);
				match(INDENTIFIER);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Query_exprContext extends ParserRuleContext {
		public List<TerminalNode> INDENTIFIER() { return getTokens(JsonPathParser.INDENTIFIER); }
		public TerminalNode INDENTIFIER(int i) {
			return getToken(JsonPathParser.INDENTIFIER, i);
		}
		public TerminalNode INTEGER() { return getToken(JsonPathParser.INTEGER, 0); }
		public List<Query_exprContext> query_expr() {
			return getRuleContexts(Query_exprContext.class);
		}
		public Query_exprContext query_expr(int i) {
			return getRuleContext(Query_exprContext.class,i);
		}
		public Query_exprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_query_expr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JsonPathListener ) ((JsonPathListener)listener).enterQuery_expr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JsonPathListener ) ((JsonPathListener)listener).exitQuery_expr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JsonPathVisitor ) return ((JsonPathVisitor<? extends T>)visitor).visitQuery_expr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Query_exprContext query_expr() throws RecognitionException {
		return query_expr(0);
	}

	private Query_exprContext query_expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		Query_exprContext _localctx = new Query_exprContext(_ctx, _parentState);
		Query_exprContext _prevctx = _localctx;
		int _startState = 12;
		enterRecursionRule(_localctx, 12, RULE_query_expr, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(226);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,16,_ctx) ) {
			case 1:
				{
				setState(90);
				match(T__12);
				}
				break;
			case 2:
				{
				setState(91);
				match(T__13);
				setState(92);
				match(INDENTIFIER);
				setState(97);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__14) {
					{
					{
					setState(93);
					match(T__14);
					setState(94);
					match(INDENTIFIER);
					}
					}
					setState(99);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(100);
				match(T__15);
				setState(101);
				match(INDENTIFIER);
				setState(102);
				match(T__16);
				}
				break;
			case 3:
				{
				setState(103);
				match(T__13);
				setState(104);
				match(INDENTIFIER);
				setState(109);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__14) {
					{
					{
					setState(105);
					match(T__14);
					setState(106);
					match(INDENTIFIER);
					}
					}
					setState(111);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(112);
				match(T__17);
				setState(113);
				match(INTEGER);
				}
				break;
			case 4:
				{
				setState(114);
				match(T__13);
				setState(115);
				match(INDENTIFIER);
				setState(120);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__14) {
					{
					{
					setState(116);
					match(T__14);
					setState(117);
					match(INDENTIFIER);
					}
					}
					setState(122);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(123);
				match(T__18);
				setState(124);
				match(INTEGER);
				}
				break;
			case 5:
				{
				setState(125);
				match(T__13);
				setState(126);
				match(INDENTIFIER);
				setState(131);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__14) {
					{
					{
					setState(127);
					match(T__14);
					setState(128);
					match(INDENTIFIER);
					}
					}
					setState(133);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(134);
				match(T__19);
				setState(135);
				match(INTEGER);
				}
				break;
			case 6:
				{
				setState(136);
				match(T__13);
				setState(137);
				match(INDENTIFIER);
				setState(142);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__14) {
					{
					{
					setState(138);
					match(T__14);
					setState(139);
					match(INDENTIFIER);
					}
					}
					setState(144);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(145);
				match(T__20);
				setState(146);
				match(INTEGER);
				}
				break;
			case 7:
				{
				setState(147);
				match(T__13);
				setState(148);
				match(INDENTIFIER);
				setState(153);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__14) {
					{
					{
					setState(149);
					match(T__14);
					setState(150);
					match(INDENTIFIER);
					}
					}
					setState(155);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(156);
				match(T__21);
				setState(157);
				match(INTEGER);
				}
				break;
			case 8:
				{
				setState(158);
				match(T__13);
				setState(159);
				match(INDENTIFIER);
				setState(164);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__14) {
					{
					{
					setState(160);
					match(T__14);
					setState(161);
					match(INDENTIFIER);
					}
					}
					setState(166);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(167);
				match(T__22);
				setState(168);
				match(INTEGER);
				}
				break;
			case 9:
				{
				setState(169);
				match(T__13);
				setState(170);
				match(INDENTIFIER);
				setState(175);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,15,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(171);
						match(T__14);
						setState(172);
						match(INDENTIFIER);
						}
						} 
					}
					setState(177);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,15,_ctx);
				}
				}
				break;
			case 10:
				{
				setState(178);
				match(T__13);
				setState(179);
				match(INDENTIFIER);
				}
				break;
			case 11:
				{
				setState(180);
				match(T__13);
				setState(181);
				match(INDENTIFIER);
				setState(182);
				match(T__18);
				setState(183);
				match(INTEGER);
				}
				break;
			case 12:
				{
				setState(184);
				match(T__13);
				setState(185);
				match(INDENTIFIER);
				setState(186);
				match(T__19);
				setState(187);
				match(INTEGER);
				}
				break;
			case 13:
				{
				setState(188);
				match(T__13);
				setState(189);
				match(INDENTIFIER);
				setState(190);
				match(T__20);
				setState(191);
				match(INTEGER);
				}
				break;
			case 14:
				{
				setState(192);
				match(T__13);
				setState(193);
				match(INDENTIFIER);
				setState(194);
				match(T__21);
				setState(195);
				match(INTEGER);
				}
				break;
			case 15:
				{
				setState(196);
				match(T__13);
				setState(197);
				match(INDENTIFIER);
				setState(198);
				match(T__22);
				setState(199);
				match(INTEGER);
				}
				break;
			case 16:
				{
				setState(200);
				match(T__23);
				setState(201);
				match(INTEGER);
				}
				break;
			case 17:
				{
				setState(202);
				match(T__13);
				setState(203);
				match(INDENTIFIER);
				setState(204);
				match(T__17);
				setState(205);
				match(INTEGER);
				}
				break;
			case 18:
				{
				setState(206);
				match(T__13);
				setState(207);
				match(INDENTIFIER);
				setState(208);
				match(T__24);
				setState(209);
				match(INDENTIFIER);
				setState(210);
				match(T__16);
				}
				break;
			case 19:
				{
				setState(211);
				match(T__13);
				setState(212);
				match(INDENTIFIER);
				setState(213);
				match(T__25);
				setState(214);
				match(INDENTIFIER);
				setState(215);
				match(T__16);
				}
				break;
			case 20:
				{
				setState(216);
				match(T__13);
				setState(217);
				match(INDENTIFIER);
				setState(218);
				match(T__26);
				setState(219);
				match(INDENTIFIER);
				setState(220);
				match(T__16);
				}
				break;
			case 21:
				{
				setState(221);
				match(T__13);
				setState(222);
				match(INDENTIFIER);
				setState(223);
				match(T__27);
				setState(224);
				match(INDENTIFIER);
				setState(225);
				match(T__16);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(244);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,20,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(242);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,19,_ctx) ) {
					case 1:
						{
						_localctx = new Query_exprContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_query_expr);
						setState(228);
						if (!(precpred(_ctx, 23))) throw new FailedPredicateException(this, "precpred(_ctx, 23)");
						setState(231); 
						_errHandler.sync(this);
						_alt = 1;
						do {
							switch (_alt) {
							case 1:
								{
								{
								setState(229);
								match(T__10);
								setState(230);
								query_expr(0);
								}
								}
								break;
							default:
								throw new NoViableAltException(this);
							}
							setState(233); 
							_errHandler.sync(this);
							_alt = getInterpreter().adaptivePredict(_input,17,_ctx);
						} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
						}
						break;
					case 2:
						{
						_localctx = new Query_exprContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_query_expr);
						setState(235);
						if (!(precpred(_ctx, 22))) throw new FailedPredicateException(this, "precpred(_ctx, 22)");
						setState(238); 
						_errHandler.sync(this);
						_alt = 1;
						do {
							switch (_alt) {
							case 1:
								{
								{
								setState(236);
								match(T__11);
								setState(237);
								query_expr(0);
								}
								}
								break;
							default:
								throw new NoViableAltException(this);
							}
							setState(240); 
							_errHandler.sync(this);
							_alt = getInterpreter().adaptivePredict(_input,18,_ctx);
						} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
						}
						break;
					}
					} 
				}
				setState(246);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,20,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 6:
			return query_expr_sempred((Query_exprContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean query_expr_sempred(Query_exprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 23);
		case 1:
			return precpred(_ctx, 22);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3!\u00fa\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\3\2\3\2\3\3\3\3\3\3\7\3"+
		"\26\n\3\f\3\16\3\31\13\3\3\3\7\3\34\n\3\f\3\16\3\37\13\3\3\4\3\4\5\4#"+
		"\n\4\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\5\5\61\n\5\3\6\3"+
		"\6\7\6\65\n\6\f\6\16\68\13\6\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\7"+
		"\7D\n\7\f\7\16\7G\13\7\3\7\3\7\7\7K\n\7\f\7\16\7N\13\7\3\7\3\7\3\7\3\7"+
		"\3\7\3\7\3\7\3\7\3\7\3\7\5\7Z\n\7\3\b\3\b\3\b\3\b\3\b\3\b\7\bb\n\b\f\b"+
		"\16\be\13\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\7\bn\n\b\f\b\16\bq\13\b\3\b\3"+
		"\b\3\b\3\b\3\b\3\b\7\by\n\b\f\b\16\b|\13\b\3\b\3\b\3\b\3\b\3\b\3\b\7\b"+
		"\u0084\n\b\f\b\16\b\u0087\13\b\3\b\3\b\3\b\3\b\3\b\3\b\7\b\u008f\n\b\f"+
		"\b\16\b\u0092\13\b\3\b\3\b\3\b\3\b\3\b\3\b\7\b\u009a\n\b\f\b\16\b\u009d"+
		"\13\b\3\b\3\b\3\b\3\b\3\b\3\b\7\b\u00a5\n\b\f\b\16\b\u00a8\13\b\3\b\3"+
		"\b\3\b\3\b\3\b\3\b\7\b\u00b0\n\b\f\b\16\b\u00b3\13\b\3\b\3\b\3\b\3\b\3"+
		"\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b"+
		"\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3"+
		"\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\5\b\u00e5\n\b\3\b\3\b\3\b\6\b\u00ea"+
		"\n\b\r\b\16\b\u00eb\3\b\3\b\3\b\6\b\u00f1\n\b\r\b\16\b\u00f2\7\b\u00f5"+
		"\n\b\f\b\16\b\u00f8\13\b\3\b\2\3\16\t\2\4\6\b\n\f\16\2\2\2\u011e\2\20"+
		"\3\2\2\2\4\22\3\2\2\2\6\"\3\2\2\2\b\60\3\2\2\2\n\62\3\2\2\2\fY\3\2\2\2"+
		"\16\u00e4\3\2\2\2\20\21\5\4\3\2\21\3\3\2\2\2\22\23\7\3\2\2\23\27\5\6\4"+
		"\2\24\26\5\6\4\2\25\24\3\2\2\2\26\31\3\2\2\2\27\25\3\2\2\2\27\30\3\2\2"+
		"\2\30\35\3\2\2\2\31\27\3\2\2\2\32\34\5\n\6\2\33\32\3\2\2\2\34\37\3\2\2"+
		"\2\35\33\3\2\2\2\35\36\3\2\2\2\36\5\3\2\2\2\37\35\3\2\2\2 #\5\b\5\2!#"+
		"\7\37\2\2\" \3\2\2\2\"!\3\2\2\2#\7\3\2\2\2$%\7\37\2\2%\61\7\4\2\2&\'\7"+
		"\37\2\2\'(\7\5\2\2()\7 \2\2)\61\7\6\2\2*+\7\37\2\2+,\7\7\2\2,-\5\16\b"+
		"\2-.\7\b\2\2.\61\3\2\2\2/\61\7\4\2\2\60$\3\2\2\2\60&\3\2\2\2\60*\3\2\2"+
		"\2\60/\3\2\2\2\61\t\3\2\2\2\62\66\5\f\7\2\63\65\5\f\7\2\64\63\3\2\2\2"+
		"\658\3\2\2\2\66\64\3\2\2\2\66\67\3\2\2\2\67\13\3\2\2\28\66\3\2\2\29:\7"+
		"\t\2\2:;\7\37\2\2;<\7\n\2\2<Z\7 \2\2=>\7\t\2\2>?\7\37\2\2?@\7\n\2\2@A"+
		"\7\37\2\2AE\7\13\2\2BD\7\37\2\2CB\3\2\2\2DG\3\2\2\2EC\3\2\2\2EF\3\2\2"+
		"\2FL\3\2\2\2GE\3\2\2\2HI\7\f\2\2IK\7\37\2\2JH\3\2\2\2KN\3\2\2\2LJ\3\2"+
		"\2\2LM\3\2\2\2MZ\3\2\2\2NL\3\2\2\2OP\7\t\2\2PQ\7\37\2\2QR\7\n\2\2RZ\7"+
		"\37\2\2ST\7\t\2\2TU\7\37\2\2UV\7\n\2\2VW\7\37\2\2WX\7\f\2\2XZ\7\37\2\2"+
		"Y9\3\2\2\2Y=\3\2\2\2YO\3\2\2\2YS\3\2\2\2Z\r\3\2\2\2[\\\b\b\1\2\\\u00e5"+
		"\7\17\2\2]^\7\20\2\2^c\7\37\2\2_`\7\21\2\2`b\7\37\2\2a_\3\2\2\2be\3\2"+
		"\2\2ca\3\2\2\2cd\3\2\2\2df\3\2\2\2ec\3\2\2\2fg\7\22\2\2gh\7\37\2\2h\u00e5"+
		"\7\23\2\2ij\7\20\2\2jo\7\37\2\2kl\7\21\2\2ln\7\37\2\2mk\3\2\2\2nq\3\2"+
		"\2\2om\3\2\2\2op\3\2\2\2pr\3\2\2\2qo\3\2\2\2rs\7\24\2\2s\u00e5\7 \2\2"+
		"tu\7\20\2\2uz\7\37\2\2vw\7\21\2\2wy\7\37\2\2xv\3\2\2\2y|\3\2\2\2zx\3\2"+
		"\2\2z{\3\2\2\2{}\3\2\2\2|z\3\2\2\2}~\7\25\2\2~\u00e5\7 \2\2\177\u0080"+
		"\7\20\2\2\u0080\u0085\7\37\2\2\u0081\u0082\7\21\2\2\u0082\u0084\7\37\2"+
		"\2\u0083\u0081\3\2\2\2\u0084\u0087\3\2\2\2\u0085\u0083\3\2\2\2\u0085\u0086"+
		"\3\2\2\2\u0086\u0088\3\2\2\2\u0087\u0085\3\2\2\2\u0088\u0089\7\26\2\2"+
		"\u0089\u00e5\7 \2\2\u008a\u008b\7\20\2\2\u008b\u0090\7\37\2\2\u008c\u008d"+
		"\7\21\2\2\u008d\u008f\7\37\2\2\u008e\u008c\3\2\2\2\u008f\u0092\3\2\2\2"+
		"\u0090\u008e\3\2\2\2\u0090\u0091\3\2\2\2\u0091\u0093\3\2\2\2\u0092\u0090"+
		"\3\2\2\2\u0093\u0094\7\27\2\2\u0094\u00e5\7 \2\2\u0095\u0096\7\20\2\2"+
		"\u0096\u009b\7\37\2\2\u0097\u0098\7\21\2\2\u0098\u009a\7\37\2\2\u0099"+
		"\u0097\3\2\2\2\u009a\u009d\3\2\2\2\u009b\u0099\3\2\2\2\u009b\u009c\3\2"+
		"\2\2\u009c\u009e\3\2\2\2\u009d\u009b\3\2\2\2\u009e\u009f\7\30\2\2\u009f"+
		"\u00e5\7 \2\2\u00a0\u00a1\7\20\2\2\u00a1\u00a6\7\37\2\2\u00a2\u00a3\7"+
		"\21\2\2\u00a3\u00a5\7\37\2\2\u00a4\u00a2\3\2\2\2\u00a5\u00a8\3\2\2\2\u00a6"+
		"\u00a4\3\2\2\2\u00a6\u00a7\3\2\2\2\u00a7\u00a9\3\2\2\2\u00a8\u00a6\3\2"+
		"\2\2\u00a9\u00aa\7\31\2\2\u00aa\u00e5\7 \2\2\u00ab\u00ac\7\20\2\2\u00ac"+
		"\u00b1\7\37\2\2\u00ad\u00ae\7\21\2\2\u00ae\u00b0\7\37\2\2\u00af\u00ad"+
		"\3\2\2\2\u00b0\u00b3\3\2\2\2\u00b1\u00af\3\2\2\2\u00b1\u00b2\3\2\2\2\u00b2"+
		"\u00e5\3\2\2\2\u00b3\u00b1\3\2\2\2\u00b4\u00b5\7\20\2\2\u00b5\u00e5\7"+
		"\37\2\2\u00b6\u00b7\7\20\2\2\u00b7\u00b8\7\37\2\2\u00b8\u00b9\7\25\2\2"+
		"\u00b9\u00e5\7 \2\2\u00ba\u00bb\7\20\2\2\u00bb\u00bc\7\37\2\2\u00bc\u00bd"+
		"\7\26\2\2\u00bd\u00e5\7 \2\2\u00be\u00bf\7\20\2\2\u00bf\u00c0\7\37\2\2"+
		"\u00c0\u00c1\7\27\2\2\u00c1\u00e5\7 \2\2\u00c2\u00c3\7\20\2\2\u00c3\u00c4"+
		"\7\37\2\2\u00c4\u00c5\7\30\2\2\u00c5\u00e5\7 \2\2\u00c6\u00c7\7\20\2\2"+
		"\u00c7\u00c8\7\37\2\2\u00c8\u00c9\7\31\2\2\u00c9\u00e5\7 \2\2\u00ca\u00cb"+
		"\7\32\2\2\u00cb\u00e5\7 \2\2\u00cc\u00cd\7\20\2\2\u00cd\u00ce\7\37\2\2"+
		"\u00ce\u00cf\7\24\2\2\u00cf\u00e5\7 \2\2\u00d0\u00d1\7\20\2\2\u00d1\u00d2"+
		"\7\37\2\2\u00d2\u00d3\7\33\2\2\u00d3\u00d4\7\37\2\2\u00d4\u00e5\7\23\2"+
		"\2\u00d5\u00d6\7\20\2\2\u00d6\u00d7\7\37\2\2\u00d7\u00d8\7\34\2\2\u00d8"+
		"\u00d9\7\37\2\2\u00d9\u00e5\7\23\2\2\u00da\u00db\7\20\2\2\u00db\u00dc"+
		"\7\37\2\2\u00dc\u00dd\7\35\2\2\u00dd\u00de\7\37\2\2\u00de\u00e5\7\23\2"+
		"\2\u00df\u00e0\7\20\2\2\u00e0\u00e1\7\37\2\2\u00e1\u00e2\7\36\2\2\u00e2"+
		"\u00e3\7\37\2\2\u00e3\u00e5\7\23\2\2\u00e4[\3\2\2\2\u00e4]\3\2\2\2\u00e4"+
		"i\3\2\2\2\u00e4t\3\2\2\2\u00e4\177\3\2\2\2\u00e4\u008a\3\2\2\2\u00e4\u0095"+
		"\3\2\2\2\u00e4\u00a0\3\2\2\2\u00e4\u00ab\3\2\2\2\u00e4\u00b4\3\2\2\2\u00e4"+
		"\u00b6\3\2\2\2\u00e4\u00ba\3\2\2\2\u00e4\u00be\3\2\2\2\u00e4\u00c2\3\2"+
		"\2\2\u00e4\u00c6\3\2\2\2\u00e4\u00ca\3\2\2\2\u00e4\u00cc\3\2\2\2\u00e4"+
		"\u00d0\3\2\2\2\u00e4\u00d5\3\2\2\2\u00e4\u00da\3\2\2\2\u00e4\u00df\3\2"+
		"\2\2\u00e5\u00f6\3\2\2\2\u00e6\u00e9\f\31\2\2\u00e7\u00e8\7\r\2\2\u00e8"+
		"\u00ea\5\16\b\2\u00e9\u00e7\3\2\2\2\u00ea\u00eb\3\2\2\2\u00eb\u00e9\3"+
		"\2\2\2\u00eb\u00ec\3\2\2\2\u00ec\u00f5\3\2\2\2\u00ed\u00f0\f\30\2\2\u00ee"+
		"\u00ef\7\16\2\2\u00ef\u00f1\5\16\b\2\u00f0\u00ee\3\2\2\2\u00f1\u00f2\3"+
		"\2\2\2\u00f2\u00f0\3\2\2\2\u00f2\u00f3\3\2\2\2\u00f3\u00f5\3\2\2\2\u00f4"+
		"\u00e6\3\2\2\2\u00f4\u00ed\3\2\2\2\u00f5\u00f8\3\2\2\2\u00f6\u00f4\3\2"+
		"\2\2\u00f6\u00f7\3\2\2\2\u00f7\17\3\2\2\2\u00f8\u00f6\3\2\2\2\27\27\35"+
		"\"\60\66ELYcoz\u0085\u0090\u009b\u00a6\u00b1\u00e4\u00eb\u00f2\u00f4\u00f6";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}